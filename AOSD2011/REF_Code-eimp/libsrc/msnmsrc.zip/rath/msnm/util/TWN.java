/*
 * @(#)TWN.java
 *
 * Copyright (c) 2001-2003, JangHo Hwang
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 	1. Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 *
 * 	2. Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 *
 * 	3. Neither the name of the JangHo Hwang nor the names of its contributors
 * may be used to endorse or promote products derived from this software
 * without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *    $Id: TWN.java,v 1.1 2003/10/16 08:48:33 xrath Exp $
 */
package rath.msnm.util;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSocketFactory;
/**
 * SSL based Passport Login class :)
 * <p>
 * TWN class is execute on JDK 1.4 or later for SSL class(javax.net.ssl.HttpsURLConnection).
 * 
 * @author Jang-Ho Hwang, imrath@empal.com
 * @version 1.0.000, 2003/10/16 
 */
public class TWN
{
	private static String getContent( InputStream in, int len ) throws IOException
	{
		byte[] buf = new byte[ 8192 ];

		int off = 0;
		while( off < buf.length )
		{
			int readlen = in.read(buf, off, buf.length-off);
			if( readlen<1 )
				break;
			off += readlen;
		}
		in.close();

		return new String(buf, 0, off);
	}

	public static String getTNP( String userid, String password, String tpf ) 
		throws IOException
	{
		String domain = "login.passport.com";
		if( userid.endsWith("@hotmail.com") )
			domain = "loginnet.passport.com";
		else
		if( userid.endsWith("@msn.com") )
			domain = "msnialogin.passport.com";

		URL url0 = new URL(
			"https://" + domain + "/ppsecure/post.srf?" + tpf.replace(',', '&') );
		
		HttpsURLConnection con0 = (HttpsURLConnection)url0.openConnection();
		con0.setRequestMethod( "POST" );
		con0.setUseCaches( false );
		con0.setDoInput( true );
		con0.setDoOutput( true );

		con0.addRequestProperty( "Cookie", "BrowserTest=Success?;version=1" );

		OutputStream out0 = con0.getOutputStream();
		String toOut = "login=" + userid + "&";
		toOut += "passwd=" + password + "&";
		toOut += "sec=&";
		toOut += "mspp_shared=0&padding=";
		toOut += "\r\n\r\n";

		out0.write( toOut.getBytes() );
		out0.flush();

		String ret = getContent( con0.getInputStream(), con0.getContentLength() );		
		con0.disconnect();

		int i0 = ret.indexOf("&t=");
		int i1 = ret.indexOf("\"", i0);

		if( i0==-1 || i1==-1 )
			return "t=0&p=0";

		String tnp = ret.substring(i0+1, i1);
		return tnp;
	}
}