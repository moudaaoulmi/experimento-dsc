/*
 * @(#)NotificationProcessor.java
 *
 * Copyright (c) 2001-2002, JangHo Hwang
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 	1. Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 *
 * 	2. Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 *
 * 	3. Neither the name of the JangHo Hwang nor the names of its contributors
 * may be used to endorse or promote products derived from this software
 * without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *    $Id: NotificationProcessor.java,v 1.19 2003/10/16 10:48:26 xrath Exp $
 */
package rath.msnm;

import java.lang.reflect.Method;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;

import rath.msnm.entity.Callback;
import rath.msnm.entity.ServerInfo;
import rath.msnm.entity.MsnFriend;
import rath.msnm.entity.Group;
import rath.msnm.msg.OutgoingMessage;
import rath.msnm.msg.IncomingMessage;
import rath.msnm.msg.MimeMessage;
import rath.msnm.msg.MimeUtility;
import rath.msnm.util.StringUtil;
import rath.msnm.util.TWN;
/**
 * NS ������ �ϻ��� �����ϴ� ���μ���
 *
 * @author Jang-Ho Hwang, rath@linuxkorea.co.kr
 * @version $Id: NotificationProcessor.java,v 1.19 2003/10/16 10:48:26 xrath Exp $
 */
public class NotificationProcessor extends AbstractProcessor implements UserStatus
{
	int lastSerial = 0;
	private String securityPackage = null;
	private String status = null;

	private Thread callbackCleaner = null;
	private Hashtable lockMap = new Hashtable();
	private Hashtable sessionMap = new Hashtable();
	private HashMap callIdMap = new HashMap();

	public NotificationProcessor( MSNMessenger msn, ServerInfo info )
	{
		this( msn, info, 0 );
	}

	public NotificationProcessor( MSNMessenger msn, ServerInfo info, int trId )
	{
		super( msn, info, trId );

		setServerName( "NS" );
	}

	/**
	 * DS���� ������ �ξ�������, ����� �����ϱ� ����
	 * Version ������ ������ ���� �ϰ� �ȴ�.
	 */
	public void init() throws IOException
	{
		OutgoingMessage msg = new OutgoingMessage("VER");
		markTransactionId( msg );
		msg.add( "MSNP9" );
		msg.add( "MSNP8" );
		msg.add( "CVRO" );
		msg.setBackProcess( Callback.getInstance("processVER", this.getClass()) );

		sendMessage( msg );
	}

	/**
	 *
	 */
	public void processMessage( IncomingMessage msg ) throws Exception
	{
		String header = msg.getHeader();

		if( header.equals("ILN") )
		{
			String status = msg.get(0);
			String login = msg.get(1);
			String friendly = msg.get(2);

			MsnFriend friend = msn.getBuddyGroup().getForwardList().get( login );
			if( friend==null )
			    friend = new MsnFriend(login, friendly);
			else
				friend.setFriendlyName( friendly );
			friend.setStatus( status );
			msn.fireListOnlineEvent( friend );
		}
		else
		if( header.equals("ADD") )
		{
			String group = msg.get(0);
			// ������ �߰��� ���� NOTIFY���̹Ƿ� trId�� 0���̴�.
			if( group.equals("RL") && msg.getTransactionId()==0 )
			{
				this.lastSerial = msg.getInt(1);
				String login = msg.get(2);
				String friendly = msg.get(3);
				// Serial �����ϰ�, ���ο� �ΰ��� LocalCopy�� ����ؾ��Ѵ�.

				MsnFriend friend = new MsnFriend(login, friendly);
				BuddyList reverse = msn.getBuddyGroup().getReverseList();
				reverse.add( friend );

				msn.storeLocalCopy( lastSerial );
				msn.fireWhoAddedMeEvent( friend );
			}
		}
		else
		if( header.equals("REM") && msg.getTransactionId()==0 )
		{
			String group = msg.get(0);
			if( group.equals("RL") )
			{
				this.lastSerial = msg.getInt(1);
				String login = msg.get(2);
				// Serial �����ϰ�, �� �ΰ��� LocalCopy���� �����ؾ��Ѵ�.

				BuddyList reverse = msn.getBuddyGroup().getReverseList();
				reverse.remove( login );

				msn.storeLocalCopy( lastSerial );
				msn.fireWhoRemovedMeEvent( new MsnFriend(login, null) );
			}
		}
		else
		if( header.equals("CHL") )
		{
			String code = StringUtil.md5(msg.get(0) + "Q1P7W2E4J9R8U3S5");

			OutgoingMessage out = new OutgoingMessage("QRY");
			markTransactionId( out );
			out.add( "msmsgs@msnmsgr.com" );
			out.add( 32 );

			sendCHLResponse( out, code );
		}
	}

	public void processNotifyMessage( IncomingMessage msg ) throws Exception
	{
		super.processNotifyMessage( msg );

		String header = msg.getHeader();

		if( header.equals("NLN") )
		{
			String status = msg.get(0);
			String login = msg.get(1);
			String friendly = msg.get(2);

			BuddyList fl = msn.getBuddyGroup().getForwardList();
			MsnFriend friend = fl.get(login);
			friend.setStatus( status );
			friend.setFriendlyName( friendly );
			msn.fireUserOnlineEvent( friend );
		}
		else
		if( header.equals("FLN") )
		{
			String login = msg.get(0);
			msn.fireUserOfflineEvent( login );
		}
		else
		if( header.equals("RNG") )
		{
			acceptRinging( msg );
		}
		else
		if( header.equals("LSG") )
		{
			doCollectGroup( msg );
		}
		else
		if( header.equals("LST") )
		{
			doCollectList( msg );
		}
	}

	protected void filterMimeMessage( MimeMessage msg ) 
	{
		if( msg.getKind()==MimeMessage.KIND_MAIL_NOTIFY )
		{
			if( msg.hasProperty("Inbox-Unread") )
				msn.fireNotifyUnreadMail( msg.getProperties(), 
					Integer.parseInt(msg.getProperty("Inbox-Unread")) );
		}
	}

	/**
	 * ��ȭ �ް� Switchboard Server�� ������ �����Ѵ�.
	 * �˾Ƽ� Internal session hashmap�� ����� ���̴�.
	 */
	protected void acceptRinging( IncomingMessage msg ) throws IOException
	{
		String sessionId = msg.get(0);
		ServerInfo serv = msg.getServerInfo(1);
		String securityPackage = msg.get(2);
		String cookie = msg.get(3);
		String destinLoginName = msg.get(4);
		String destinFriendlyName = msg.get(5);

		// Throw calling friend information
		// I need not :)
		SwitchboardSession ss = new SwitchboardSession( msn, serv, sessionId );
		ss.setCookie( cookie );
		ss.start();
	}

	public void processVER( IncomingMessage msg ) throws Exception
	{
		OutgoingMessage out = new OutgoingMessage("CVR");
		markTransactionId( out );
		out.add( "0x0412" ); // What is it?
		out.add( System.getProperty("os.name").replace(' ', '_') ); // OS name
		out.add( System.getProperty("os.version") ); // OS version
		out.add( System.getProperty("os.arch") ); // OS architecture
		out.add( "MSNMSGR" );
		out.add( "6.0.0602" );
		out.add( "MSMSGS" );
		out.add( msn.getLoginName() );
		out.setBackProcess( Callback.getInstance("processCVR", this.getClass()) );

		sendMessage( out );
	}

	public void processCVR( IncomingMessage msg ) throws Exception
	{
		// Microsoft doesn't provide security package.
		// this.securityPackage = msg.get(0);
		this.securityPackage = "TWN"; // SSL based

		OutgoingMessage out = new OutgoingMessage("USR");
		markTransactionId( out );
		out.add( this.securityPackage );
		out.add( "I" );
		out.add( msn.getLoginName() );
		out.setBackProcess( Callback.getInstance("processAuth", this.getClass()) );

		sendMessage( out );
	}

	public void processAuth( IncomingMessage msg ) throws Exception
	{
		if( msg.getHeader().equals("XFR") &&
		    msg.get(0).equals("NS") )
		{
		    ServerInfo info = msg.getServerInfo(1);
			this.setServerInfo(info);
			makeConnection();
			init();
			return;
		}

		OutgoingMessage out = new OutgoingMessage("USR");
		markTransactionId( out );
		out.add( this.securityPackage );
		out.add( "S" );
		if( securityPackage.equals("MD5") )
		{
			out.add( StringUtil.md5(msg.get(2)+msn.getPassword()) );
		}
		else
		if( securityPackage.equals("TWN") )
		{
			out.add( TWN.getTNP(msn.getLoginName(), msn.getPassword(), msg.get(2)) );
		}

		out.setBackProcess( Callback.getInstance("processLogon", this.getClass()) );

		sendMessage( out );
	}

	public void processLogon( IncomingMessage msg ) throws Exception
	{
		// Authentication failed.
		if( !msg.getHeader().equals("USR") )
		{
			msn.fireLoginErrorEvent( msg.getHeader() );
			return;
		}

		Callback cb = Callback.getInstance("judgeSerial", this.getClass());

		OutgoingMessage out = new OutgoingMessage("SYN");
		markTransactionId( out );
		out.add( lastSerial );
		out.setBackProcess( cb );

		sendMessage( out );

		msn.isLogged = true;
		msn.fireLoginCompleteEvent( new MsnFriend(msg.get(1),msg.get(2)) );
	}

	/**
	 * NS�� SYN ������ �޾����� ȣ��Ǹ�,
	 * Client�� serial�� Server�� serial�� ���� �ٸ� ���
	 * RL�� FL�� List-up�Ͽ� sync�� �����.
	 */
	public void judgeSerial( IncomingMessage msg ) throws IOException
	{
		int serverSerial = msg.getInt(0);
		if( serverSerial!=lastSerial )
		{
			this.lastSerial = serverSerial;

			// ��� ������ Msg�� TrID�� �״�� ��Ƽ�,
			// callbackMap�� ���ο� GTC, BLP, LST�� ���ʴ�� �������Ѵ�.
			
			//Callback cb = Callback.getInstance("doCollectList", this.getClass());
			//cb.setInfinite();
			//registerCallback(new Integer(msg.getTransactionId()), cb);

			/*
			 * GTC, BLP, �׸��� FL/RL/AL/BL�� ���� LST�� �츣�� ������ ���̴�.
			 * GTC�� BLP�� Server�� �����Ǵ� ���� �����ϻ��̴�.
			 * �׷��Ƿ� ���⼭ ������� GTC�� BLP�� Ȯ�μ� �޽����̱⶧����
			 * ũ�� �߿����� �����Ƿ� ����� �����Ѵ�.
			 *
			 * ���� ����Ʈ�� ��â ���� ���̹Ƿ� List�� clear�ؾ��Ѵ�.			 * 
			 */
			BuddyGroup bg = msn.getBuddyGroup();
			bg.getForwardList().clear();
			bg.getAllowList().clear();
			bg.getBlockList().clear();
			bg.getReverseList().clear();			
		}

		setMyStatus( msn.getInitialStatus() );
	}

	/**
	 * Collect LSG Message
	 */
	public void doCollectGroup( IncomingMessage msg ) throws IOException
	{
		GroupList gl = msn.getBuddyGroup().getGroupList();

		int gIndex = msg.getInt(0);
		String gName = MimeUtility.getURLDecodedString( msg.get(1), "UTF-8" );

		Group group = new Group(gName, gIndex);
		gl.addGroup(group);
	}

	public void doCollectList( IncomingMessage msg ) throws IOException
	{
		String hisLoginName = msg.get(0);
		String hisFriendlyName = msg.get(1);
		int accessId = msg.getInt(2);
		int groupIndex = 0;
		if( msg.size() > 3 )
		{
			String gis = msg.get(3);
			if( gis.indexOf(',')!=-1 )
				gis = gis.substring(0, gis.indexOf(','));
			groupIndex = Integer.parseInt(gis);
		}

		MsnFriend friend = new MsnFriend( hisLoginName );
		friend.setFriendlyName( hisFriendlyName );
		friend.setGroupIndex( groupIndex );

		BuddyGroup bg = msn.getBuddyGroup();

		/*
		 * ������ ����Ʈ�� �����Ѵ�.
		 * ��� �̹� ILN ���� List�� ��ϵǾ����� �� ������,
		 * ���°��� �������� ������ �Ѵ�.
		 */
		if( bg.isListForward(accessId) )
			fixAdd( bg.getForwardList(), hisLoginName, friend, groupIndex );
		if( bg.isListAllow(accessId) )
			fixAdd( bg.getAllowList(), hisLoginName, friend, groupIndex );
		if( bg.isListBlock(accessId) )
			fixAdd( bg.getBlockList(), hisLoginName, friend, groupIndex );
		if( bg.isListReverse(accessId) )
			fixAdd( bg.getReverseList(), hisLoginName, friend, groupIndex );

		/*
		 * Cannot determine that list completed.
		 * Sooooooooooooooo overhead :(
		 */
		collectComplete(msg);
	}

	private void fixAdd( BuddyList list, String loginName, MsnFriend friend, int groupIndex )
	{
		MsnFriend old = list.get( loginName );
		if( old!=null )
			friend.setStatus( old.getStatus() );
		list.add( friend );
		if( old!=null )
			old.setGroupIndex( groupIndex );
	}

	private void collectComplete( IncomingMessage msg ) throws IOException
	{		
		msn.storeLocalCopy( lastSerial );
		msn.fireAllListUpdatedEvent();		
	}

	/**
	 * �ڽ��� ���¸� �����Ѵ�. ���氡���� �����ڵ�� UserStatus �������̽���
	 * ���ǵ� �͸��� ����Ͽ��߸� �Ѵ�.
	 */
	public void setMyStatus( String code ) throws IOException
	{
		this.status = code;

		OutgoingMessage out = new OutgoingMessage("CHG");
		markTransactionId( out );
		out.add( code );

		sendMessage( out );
	}

	public String getMyStatus()
	{
		return this.status;
	}

	public void setMyFriendlyName( String newName ) throws IOException
	{
		Callback cb = Callback.getInstance("processRename", this.getClass());

		OutgoingMessage out = new OutgoingMessage("REA");
		markTransactionId( out );
		out.add( msn.getOwner().getLoginName() );
		out.add( StringUtil.replaceString(newName, " ", "%20") );
		out.setBackProcess( cb );

		sendMessage( out );
	}

	public void processRename( IncomingMessage msg ) throws IOException
	{
		if( !msg.getHeader().equals("REA") )
		{
			// Error, maybe 209? (Invalid friendly name)
			// For instance, request name include 'MSN', you'll fail.
			msn.fireRenameNotifyEvent( null );
			return;
		}

		int sn = msg.getInt(0);
		String ln = msg.get(1);
		String fn = msg.get(2);

		this.lastSerial = sn;
		msn.storeLocalCopy( lastSerial );

		msn.fireRenameNotifyEvent( new MsnFriend(ln, fn) );
	}

	/**
	 * ���μ��� thread�� �����Ѵ�.
	 */
	public void start()
	{
		if( callbackCleaner==null )
			startCallbackCleaner();
		super.start();
	}

	/**
	 * Remove garbage callback per 30 minutes.
	 * If callback's delay time over 3 minute, that callback should be removed.
	 */
	private void startCallbackCleaner()
	{
		callbackCleaner = new Thread( new Runnable() {
			public final void run()
			{
				try
				{
					while(true)
					{
						Thread.currentThread().sleep( 1000*60*30 );
						long limit = System.currentTimeMillis() - (long)(1000*60*5);
						synchronized( callbackMap )
						{
							for(Iterator i=callbackMap.values().iterator(); i.hasNext(); )
							{
								Callback cb = (Callback)i.next();
								if( cb.getCreationTime() < limit )
									i.remove();
							}
						}
					}
				}
				catch( InterruptedException e ) {}
				catch( Exception e )
				{
					processError( e );
				}
			}
		});
		callbackCleaner.setPriority( Thread.MIN_PRIORITY );
		callbackCleaner.start();
	}

	/**
	 * �־��� loginName���� ��ȭ��û ���μ����� �����Ѵ�.
	 */
	public void doCallFriend( String loginName ) throws IOException
	{
		Callback cb = Callback.getInstance("connectToSwitchboard", this.getClass());

		OutgoingMessage out = new OutgoingMessage("XFR");
		markTransactionId( out );
		out.add( "SB" );
		out.setBackProcess( cb );

		callIdMap.put( new Integer(out.getTransactionId()), loginName );

		sendMessage( out );
	}

	public void requestAdd( String loginName ) throws IOException
	{
		Callback cb = Callback.getInstance("responseAdd", this.getClass());

		OutgoingMessage out = new OutgoingMessage("ADD");
		markTransactionId( out );
		out.add( "FL" );
		out.add( loginName );
		out.add( loginName );
		out.setBackProcess( cb );

		sendMessage( out );

		OutgoingMessage out2 = new OutgoingMessage("ADD");
		markTransactionId( out2 );
		out2.add( "AL" );
		out2.add( loginName );
		out2.add( loginName );
		out2.setBackProcess( cb );

		sendMessage( out2 );
	}

	public void responseAdd( IncomingMessage msg ) throws IOException
	{
		String header = msg.getHeader();
		if( header.equals("ADD") )
		{
			String code = msg.get(0);
			lastSerial =  msg.getInt(1);
			String loginName = msg.get(2);
			String custom = msg.get(3);

			MsnFriend friend = new MsnFriend(loginName, custom);
			BuddyList bl = msn.getBuddyGroup().getListAsCode(code);
			if( bl!=null )
				bl.add( friend );

			msn.storeLocalCopy( lastSerial );
		}
		else
		{
			try {
				int errorCode = Integer.parseInt( header );
				msn.fireAddFailedEvent( errorCode );
			} catch( NumberFormatException e ) {}
		}
	}

	public void requestRemove( String loginName ) throws IOException
	{
		Callback cb = Callback.getInstance("responseRemove", this.getClass());

		OutgoingMessage out = new OutgoingMessage("REM");
		markTransactionId( out );
		out.add( "FL" );
		out.add( loginName );
		out.setBackProcess( cb );

		sendMessage( out );

		OutgoingMessage out2 = new OutgoingMessage("REM");
		markTransactionId( out2 );
		out2.add( "AL" );
		out2.add( loginName );
		out2.setBackProcess( cb );

		sendMessage( out2 );
	}

	public void responseRemove( IncomingMessage msg ) throws IOException
	{
		if( msg.getHeader().equals("REM") )
		{
			String code = msg.get(0);
			lastSerial =  msg.getInt(1);
			String loginName = msg.get(2);

			BuddyList bl = msn.getBuddyGroup().getListAsCode(code);
			if( bl!=null )
				bl.remove( loginName );

			msn.storeLocalCopy( lastSerial );
		}
	}

	/**
	 * Block/Unblock the specified user.
	 */
	public void requestBlock( String loginName, boolean isUnblock ) 
		throws IOException
	{
		BuddyList fl = msn.getBuddyGroup().getForwardList();
		MsnFriend friend = fl.get( loginName );
		if( friend==null )
			return;

		Callback cb = Callback.getInstance("responseBlock", this.getClass());

		OutgoingMessage out = new OutgoingMessage("REM");
		markTransactionId( out );
		out.add( isUnblock ? "BL" : "AL" );
		out.add( loginName );
		out.setBackProcess( cb );

		sendMessage( out );

		OutgoingMessage out2 = new OutgoingMessage("ADD");
		markTransactionId( out2 );
		out2.add( isUnblock ? "AL" : "BL" );
		out2.add( loginName );
		out2.add( friend.getFriendlyName() );
		out2.setBackProcess( cb );

		sendMessage( out2 );
	}

	/**
	 * Callback to unblock user.
	 */
	public void responseBlock( IncomingMessage msg ) throws IOException
	{
		String header = msg.getHeader();
		
		if( Character.isDigit(header.charAt(0)) )
			return;

		String code = msg.get(0);
		lastSerial =  msg.getInt(1);
		String loginName = msg.get(2);
		
		BuddyList bl = msn.getBuddyGroup().getListAsCode(code);
		if( bl!=null )
		{
			if( header.equals("REM") )
			{
				bl.remove( loginName );
				msn.storeLocalCopy( lastSerial );
			}
			else
			if( header.equals("ADD") )
			{
				BuddyList fl = msn.getBuddyGroup().getForwardList();
				MsnFriend friend = fl.get(loginName);
				if( friend!=null )
				{
					bl.add( friend );
					msn.storeLocalCopy( lastSerial );
				}
			}
		}		
	}

	/**
	 * �־��� ģ���� �׷��� �����Ѵ�.
	 * ������ ������ �����ϵ��� �����Ǿ������Ƿ�, �����߻��� �� ����� ����.
	 */
	public void requestMoveGroup( MsnFriend friend, int oldIndex, int newIndex )
		throws IOException
	{
		Callback cb = Callback.getInstance("responseGroupAdd", this.getClass());
		OutgoingMessage out = new OutgoingMessage("ADD");
		markTransactionId( out );
		out.add( "FL" );
		out.add( friend.getLoginName() );
		out.add( friend.getFriendlyName() );
		out.add( newIndex );
		out.setBackProcess( cb );

		sendMessage( out );

		cb = Callback.getInstance("responseGroupRemove", this.getClass());
		OutgoingMessage out2 = new OutgoingMessage("REM");
		markTransactionId( out2 );
		out2.add( "FL" );
		out2.add( friend.getLoginName() );
		out2.add( oldIndex );
		out2.setBackProcess( cb );

		sendMessage( out2 );
	}

	public void responseGroupAdd( IncomingMessage msg ) throws IOException
	{
		if( msg.size() < 5 )
			return;

		String code = msg.get(0);
		int lastSerial = msg.getInt(1);
		String ln = msg.get(2);
		String fn = msg.get(3);
		int groupIndex = msg.getInt(4);

		BuddyList bl = msn.getBuddyGroup().getListAsCode(code);
		if( bl!=null )
		{
			MsnFriend f = bl.get( ln );
			f.setFriendlyName( fn );
			f.setGroupIndex( groupIndex );
		}

		msn.storeLocalCopy( lastSerial );
	}

	public void responseGroupRemove( IncomingMessage msg ) throws IOException
	{
		if( msg.size() < 2 )
			return;

		String code = msg.get(0);
		int lastSerial = msg.getInt(1);

		msn.storeLocalCopy( lastSerial );
	}

	// �׷� �߰�,����,Rename ���� method

	/**
	 *
	 * @param groupName �Ϲ����� �׷��̸��� �ִ´�.
	 *                  �� �޼ҵ峻�ο��� �� �׷��̸��� UTF-8 URL Encoding�� ���̴�.
	 * @throws IOException
	 */
	public void requestCreateGroup( String groupName ) throws IOException
	{
		Callback cb = Callback.getInstance("responseCreateGroup", this.getClass());
		OutgoingMessage out = new OutgoingMessage("ADG");
		markTransactionId( out );
		out.add( MimeUtility.getURLEncodedString(groupName, "UTF-8") );
		out.add( 0 );
		out.setBackProcess( cb );

		sendMessage( out );
	}

	public void responseCreateGroup( IncomingMessage msg ) throws IOException
	{
		if( msg.getHeader().equals("ADG") )
		{
		    int sn = msg.getInt(0);
		    String newName = MimeUtility.getURLDecodedString(msg.get(1), "UTF-8");
			int index = msg.getInt(2);

			Group group = new Group( newName, index );
			GroupList gl = msn.getBuddyGroup().getGroupList();
			gl.addGroup( group );

			msn.storeLocalCopy( this.lastSerial = sn );
		}
	}

	public void requestRemoveGroup( int groupIndex ) throws IOException
	{
		Callback cb = Callback.getInstance("responseRemoveGroup", this.getClass());
		OutgoingMessage out = new OutgoingMessage("RMG");
		markTransactionId( out );
		out.add( groupIndex );
		out.setBackProcess( cb );

		sendMessage( out );
	}

	public void responseRemoveGroup( IncomingMessage msg ) throws IOException
	{
		if( msg.getHeader().equals("RMG") )
		{
		    int sn = msg.getInt(0);
			int index = msg.getInt(1);

			this.lastSerial = sn;

			GroupList gl = msn.getBuddyGroup().getGroupList();
			gl.removeGroup(index);
			msn.storeLocalCopy(lastSerial);
		}
	}

	public void requestRenameGroup( int groupIndex, String newName ) throws IOException
	{
		Callback cb = Callback.getInstance("responseRenameGroup", this.getClass());
		OutgoingMessage out = new OutgoingMessage("REG");
		markTransactionId( out );
		out.add( groupIndex );
		out.add( MimeUtility.getURLEncodedString(newName, "UTF-8") );
		out.add( 0 );
		out.setBackProcess( cb );

		sendMessage( out );
	}

	public void responseRenameGroup( IncomingMessage msg ) throws IOException
	{
		if( msg.getHeader().equals("REG") )
		{
			int sn = msg.getInt(0);
		    GroupList gl = msn.getBuddyGroup().getGroupList();
		    int index = msg.getInt(1);
			String newName = MimeUtility.getURLDecodedString(msg.get(2), "UTF-8");

			Group g = gl.getGroup(index);
			g.setName( newName );

			msn.storeLocalCopy( this.lastSerial=sn );
		}
	}

	/**
	 * �־��� loginName���� ��ȭ��û ���μ����� �����ϰ�, ������ ����ɶ�����
	 * ��� ��ٸ���.
	 *
	 * @since 2002/01/07, rath@linuxkorea.co.kr
	 * @return ����� SwitchboardSession
	 */
	public SwitchboardSession doCallFriendWait( String loginName )
		throws IOException, InterruptedException
	{
		Callback cb = Callback.getInstance("connectToSwitchboard", this.getClass());

		OutgoingMessage out = new OutgoingMessage("XFR");
		markTransactionId( out );
		out.add( "SB" );
		out.setBackProcess( cb );

		Integer tr = new Integer(out.getTransactionId());
		callIdMap.put( tr, loginName );

		sendMessage( out );

		// For wait, create temporary lock object and push lock map.
		// It will notify by callback process

		Object lock = new Object();
		lockMap.put( tr, lock );

		synchronized( lock )
		{
			lock.wait(10000);
		}

		return (SwitchboardSession)sessionMap.get(tr);
	}

	/**
	 * ��ȭ�� �����ϱ� ���� NS�� ���� ���ο� SS�� �ּҸ� ������
	 * SS�� �����ϰ� Calling��û�� �����Ѵ�.
	 */
	public void connectToSwitchboard( IncomingMessage msg ) throws IOException
	{
		if( callIdMap.size()==0 )
			return;

		ServerInfo serv = msg.getServerInfo(1);
		if( serv==null )
			return;

		final Integer tr = new Integer(msg.getTransactionId());
		final String cookie = msg.get(3);
		final String toCallLoginName = (String)callIdMap.get(new Integer(msg.getTransactionId()));

		SwitchboardSession ss = new SwitchboardSession( msn, serv, null ) {

			private String firstCallName = null;
			private boolean isFirstJoin = true;

			public void init() throws IOException
			{
				this.firstCallName = toCallLoginName;
				Callback cb = Callback.getInstance("processUserCall", this.getClass());

				OutgoingMessage out = new OutgoingMessage("USR");
				markTransactionId( out );
				out.add( msn.getLoginName() );
				out.add( cookie );
				out.setBackProcess( cb );

				sendMessage( out );
			}

			public void processUserCall( IncomingMessage msg ) throws IOException
			{
				// USR trId OK MyLoginName MyFriendlyName
				// I need not yet. :)

				Callback cb = Callback.getInstance("processCallResult",this.getClass());

				OutgoingMessage out = new OutgoingMessage("CAL");
				markTransactionId( out );
				out.add( firstCallName );
				out.setBackProcess( cb );

				sendMessage( out );
			}

			protected void processWhoJoined( IncomingMessage msg ) throws Exception
			{
				super.processWhoJoined( msg );

				if( isFirstJoin )
				{
					isFirstJoin = false;
					if( lockMap.containsKey(tr) )
					{
						sessionMap.put( tr, this );
						Object lock = lockMap.remove(tr);
						synchronized(lock)
						{
							lock.notify();
						}
					}
				}
			}

			public void processCallResult( IncomingMessage msg ) throws IOException
			{
				String sessionId = msg.get(1);
				setSessionId( sessionId );
				msn.fireSwitchboardSessionStartedEvent( this );
			}

			public void cleanUp()
			{
			    super.cleanUp();

				if( getSessionId()==null )
				    msn.fireSwitchboardSessionAbandonEvent( this, firstCallName );
			}
		};
		ss.start();
	}

	public void cleanUp()
	{
		if( callbackCleaner!=null )
		{
			callbackCleaner.interrupt();
			callbackCleaner = null;
		}
		msn.isLogged = false;
		msn.fireLogoutNotifyEvent();
	}

	/**
	 * NS���� OUT�ڵ带 �����ϰ� ������ �����Ѵ�.
	 */
	public void logout() throws IOException
	{
		cleanUp();

		isLive = false;
		setAutoOutSend( true );

		OutgoingMessage out = new OutgoingMessage("OUT");
		sendMessage( out );

		interrupt();
	}
};
