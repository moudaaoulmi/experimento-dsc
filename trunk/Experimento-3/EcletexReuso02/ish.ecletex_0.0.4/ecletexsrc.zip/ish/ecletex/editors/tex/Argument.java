/*
 * Created on 19-Sep-2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package ish.ecletex.editors.tex;

/**
 * @author ish
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class Argument {
	public String word;
	public String description;
	
	public Argument(String word,String description){
		this.word = word;
		this.description = description;
	}
}
