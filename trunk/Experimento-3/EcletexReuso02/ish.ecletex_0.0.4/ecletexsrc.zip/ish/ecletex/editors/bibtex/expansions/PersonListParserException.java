/*
 * Created on Mar 28, 2003
 *
 * @author henkel@cs.colorado.edu
 * 
 */
package ish.ecletex.editors.bibtex.expansions;

/**
 * @author henkel
 */
class PersonListParserException extends java.lang.Exception {
	PersonListParserException(String message) {
		super(message);
	}
}