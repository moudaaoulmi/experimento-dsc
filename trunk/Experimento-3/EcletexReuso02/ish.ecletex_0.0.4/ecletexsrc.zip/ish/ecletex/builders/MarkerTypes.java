/*
 * Created on 14-Mar-2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package ish.ecletex.builders;

/**
 * @author ish
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class MarkerTypes {	
	public static String VBOX = "ish.ecletex.VBOX";
	public static String FONT_ERROR = "ish.ecletex.FONT_ERROR";
	public static String UNDERFULL_HBOX = "ish.ecletex.UNDERFULL_HBOX";
	public static String OVERFULL_HBOX = "ish.ecletex.OVERFULL_HBOX";
	public static String FLOAT_WARNING = "ish.ecletex.FLOAT_WARNING";
	public static String NOFILE_ERROR = "ish.ecletex.NOFILE_ERROR";
	public static String REFERENCE_ERROR = "ish.ecletex.REFERENCE_ERROR";
	public static String LATEX_WARNING = "ish.ecletex.LATEX_WARNING";
	public static String ERRORMESSAGE = "ish.ecletex.ERRORMESSAGE";
	

}
