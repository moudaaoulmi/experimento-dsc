package ymsg.network;

import java.net.URL;

public class AccountLockedException extends YahooException
{	URL location;

	public AccountLockedException(String m,URL u)
	{	super(m);  location=u;
	}
	
	public URL getWebPage() { return location; }
}
