package ymsg.network;

public class LoginRefusedException extends YahooException
{	public LoginRefusedException(String m) { super(m); }
}
