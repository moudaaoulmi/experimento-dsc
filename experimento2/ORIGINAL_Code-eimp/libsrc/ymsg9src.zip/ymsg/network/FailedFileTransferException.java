package ymsg.network;

public class FailedFileTransferException extends java.lang.RuntimeException
{	public FailedFileTransferException(String m) { super(m); }
}
