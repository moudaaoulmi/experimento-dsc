package ymsg.network;

import java.util.Vector;

public class YahooGroup extends Vector
{	protected String name;
	protected boolean open;
	
	public YahooGroup(String n,boolean o)
	{	name=n;  open=o;
	}

	public YahooGroup(String n)
	{	this(n,true);
	}
	
	public String getName() { return name; }
	public boolean isOpen() { return open; }
	public void setOpen(boolean b) { open=b; }
	public YahooUser getUserAt(int i) { return (YahooUser)elementAt(i); }
	
	public synchronized int getIndexOfFriend(String id)
	{	for(int i=0;i<size();i++)
		{	if( ((YahooUser)elementAt(i)).getId().equals(id) )
				return i;
		}
		return -1;
	}
	
	public String toString()
	{	return "name="+name+" open?="+open;
	}
}
