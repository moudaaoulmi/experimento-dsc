package ymsg.network;

//import java.util.Vector;
//import java.util.StringTokenizer;

abstract class Util
{	/*public static Vector separatedListToVector(String s,String sep)
	{	Vector v = new Vector();
		StringTokenizer st = new StringTokenizer(s,sep);
		while(st.hasMoreTokens())  v.addElement(st.nextToken());
		return v;
	}*/
	
	public static boolean debugMode;
	
	static
	{	String p = System.getProperty("ymsg.debug","false");
		debugMode = (p.equalsIgnoreCase("true"));
	}

	// -----------------------------------------------------------------
	// Is Utf-8 text
	// -----------------------------------------------------------------
	public static boolean isUtf8(String s)
	{	for(int i=0;i<s.length();i++)
		{	if(s.charAt(i) > 0x7f)  return true;
		}
		return false;
	}

	// -----------------------------------------------------------------
	// Mutex lock used simply to prevent different outputs getting entangled
	// -----------------------------------------------------------------
	synchronized static void dump(byte[] array)
	{	String s,c="";
		for(int i=0;i<array.length;i++)
		{	s="0"+Integer.toHexString((int)array[i]);
			System.out.print(s.substring(s.length()-2)+" ");
			if((int)array[i]>=' ' && (int)array[i]<='~')  c=c+(char)array[i];
				else  c=c+".";
			if((i+1)==array.length)
			{	while((i%20)!=19) { System.out.print("   ");  i++; }
			}
			if( (((i+1)%20)==0) || ((i+1)>=array.length) )
			{	System.out.print(" "+c+"\n");  c="";
			}
		}
	}
	static void dump(byte[] array,String s)
	{	System.out.println(s+"\n01-02-03-04-05-06-07-08-09-10-11-12-13-14-15-16-17-18-19-20");
		dump(array);	
	}
	
	// -----------------------------------------------------------------
	// Revert a base64 (yahoo64) encoded string back to its original
	// unsigned byte data.
	// -----------------------------------------------------------------
	static int[] yahoo64Decode(String s)
	{	if(s.length()%4!=0)  throw new IllegalArgumentException("Source string incomplete");

		// -----Figure out the correct length for byte buffer
		int len = s.length()/4;
		if(s.endsWith("--"))  len-=2;
		else if(s.endsWith("-"))  len--;
		
		int[] buffer = new int[len];
		int[] c = new int[4];
		int bpos=0;

		// -----For data streams which were not exactly divisible by three
		// -----bytes, the below will result in an exception for the padding
		// -----chars on the end of the string.
		try
		{	for(int i=0;i<s.length();i+=4)
			{	for(int j=0;i<c.length;j++)  c[j]=_c2b(s.charAt(i+j));
				buffer[bpos+0] = ( (c[0]<<2)		+ (c[1]>>4)	) & 0xff;
				buffer[bpos+1] = ( (c[1]&0x0f)<<4	+ (c[2]>>2)	) & 0xff;
				buffer[bpos+2] = ( (c[2]&0x03)<<6	+ (c[3])	) & 0xff;
				bpos+=3;
			}
		}catch(ArrayIndexOutOfBoundsException e) {}
		return buffer;
	}			
	private static int _c2b(int c)
	{	if(c>='A' && c<='Z')		return c-'A';
		else if(c>='a' && c<='z')	return c-'a'+26;
		else if(c>='0' && c<='9')	return c-'0'+52;
		else if(c=='.')				return 62;
		else if(c=='_')				return 63;
		else						return 0;
	}
	
	public static void main(String[] args)
	{	int[] b = yahoo64Decode(args[0]);
		for(int i=0;i<b.length;i++)  System.out.print(i+" ");
		System.out.print("\n");
	}
}
