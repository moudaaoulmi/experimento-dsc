package ymsg.network;

import ymsg.network.event.*;
import java.awt.Component;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.*;
import java.net.*;
import java.security.NoSuchAlgorithmException;
import java.util.*;

// *********************************************************************
// Written by FISH, Feb 2003 , Copyright FISH 2003
//
// This class represents the main entry point into the YMSG9 API.  A
// Session represents one IM connection.
// *********************************************************************
public class Session implements StatusConstants, ServiceConstants, NetworkConstants
{	// -----Misc Yahoo data
	private String username;				// Yahoo user id
	private String effectiveID;				// Effective Yahoo user id (not implemented)
	private String password;				// Yahoo user password
	private String cookieY,cookieT,cookieC; // Yahoo cookies (mmmm cOOOokies :)
	private String imvironment;				// IMvironment (decor, etc.)
	private long status;					// Yahoo status (available... etc)
	private String customStatusMessage;		// Message for custom status
	private boolean customStatusBusy;		// Available/Back=f, away=t
	private YahooGroup[] groups;			// Yahoo user's groups
	private String[] identities;			// Yahoo user's identities
	private Hashtable users;				// Key=yahoo_id, value=YahooUser
	private int conferenceCount;			// Creating conference room names
	// -----Session
	private int sessionStatus;				// Status of session (see StatusConstants)
	private long sessionId=0;				// Holds Yahoo's session id	
	private Vector listeners;				// Event listeners
	// -----I/O
	private ConnectionHandler network;		// Connection handler concrete
	// -----Threads
	private ThreadGroup ymsgThreads;		// Messenger threadgroup
	private InputThread ipThread;			// Async read from socket
	private PingThread pingThread;			// Send ping every 20 minutes
	private Hashtable typingNotifiers;		// Typing notification threads
	// -----Login
	private boolean loginOver=false;		// Marks start/end of logon process
	private YahooException loginException=null; // Exception created by login
	// -----Conferences
	private Hashtable conferences;			// Current conferences, hashed on room


	// -----------------------------------------------------------------
	// CONSTRUCTORS
	// -----------------------------------------------------------------
	public Session(ConnectionHandler ch)
	{	network=ch;  _init();
	}
	
	public Session()
	{	Properties p = System.getProperties();
		if(p.containsKey(SOCKS_HOST))
			network = new SOCKSConnectionHandler();
		else if(p.containsKey(PROXY_HOST) || p.containsKey(PROXY_HOST_OLD))
			network = new HTTPConnectionHandler();
		else
			network = new DirectConnectionHandler();
		_init();
	}
	
	private void _init()
	{	status=STATUS_AVAILABLE;  sessionId=0;  sessionStatus=UNSTARTED;
		ymsgThreads = new ThreadGroup("YMSG Threads");
		groups=null;  identities=null;
		listeners = new Vector();
		users = new Hashtable();  conferences = new Hashtable();
		typingNotifiers = new Hashtable();

		network.install(this,ymsgThreads);
	}

	// -----------------------------------------------------------------
	// Event handler listeners
	// -----------------------------------------------------------------
	public void addSessionListener(SessionListener ss)
	{	if(listeners.indexOf(ss)<0)  listeners.addElement(ss);
	}
	
	public void removeSessionListener(SessionListener ss)
	{	listeners.removeElement(ss);
	}

	// -----------------------------------------------------------------
	// Returns the handler used to send/receive messages from the network
	// -----------------------------------------------------------------
	public ConnectionHandler getConnectionHandler() { return network; }

	// -----------------------------------------------------------------
	// Call this to connect to the Yahoo server and do all the initial
	// Handshaking and accepting of data
	// u - Yahoo id (username)
	// p - password
	// -----------------------------------------------------------------
	public synchronized void login(String u,String p)
	throws IllegalStateException,IOException,AccountLockedException,LoginRefusedException
	{	// -----Check the session status first
		if(sessionStatus!=UNSTARTED)
			throw new IllegalStateException("Session should be unstarted");
		
		// -----Reset session and init some variables
		username=u;  password=p;  effectiveID=username;  
		sessionId=0;  imvironment="0";
		try
		{	// -----Open the socket, create input and output streams
			network.open();
			
			// -----Create the socket input thread, begin the login process and 
			// -----wait politely for its conclusion
			loginOver = false;
			startThreads();
			transmitAuth();	
			while(!loginOver)  
				try { Thread.sleep(10); } catch(InterruptedException e) {}
			if(sessionStatus==FAILED && loginException!=null)
			{	if(loginException instanceof AccountLockedException) 
					throw (AccountLockedException)loginException;
				else if(loginException instanceof LoginRefusedException)
					throw (LoginRefusedException)loginException;
			}
		}
		finally
		{	// -----Logon failure?  Close the input thread and reset all data
			if(sessionStatus != MESSAGING)
			{	killThreads();  cleanUp();
			}
		}
	}

	public synchronized void logout() 
	throws IllegalStateException,IOException
	{	checkStatus();
		try { transmitLogoff(); }
		finally { sessionStatus=UNSTARTED;  killThreads();  cleanUp(); }
	}
	
	// -----------------------------------------------------------------
	// Reset a failed session, so the session object can be used again
	// (for all those who like to minimise the number of discarded objects
	// for the GC to clean up  ;-)
	// -----------------------------------------------------------------
	public synchronized void reset() throws IllegalStateException
	{	if(sessionStatus!=FAILED && sessionStatus!=UNSTARTED)
			throw new IllegalStateException("Session currently active");
		
		sessionStatus=UNSTARTED;  cleanUp();
	}

	// -----------------------------------------------------------------
	// Send a message
	// to - the Yahoo ID to transmit to
	// msg - message text
	// -----------------------------------------------------------------
	public void sendMessage(String to,String msg) 
	throws IllegalStateException,IOException
	{	checkStatus();  transmitMessage(to,msg);
	}
	
	// -----------------------------------------------------------------
	// Get the status of the session, ie: unstarted, authenticating, etc.
	// Legit values are in the StatusConstants interface.  Check this
	// after login() to find out if you've connected to Yahoo okay.
	// -----------------------------------------------------------------
	public int getSessionStatus() { return sessionStatus; }

	// -----------------------------------------------------------------
	// Get/set the Yahoo status, ie: available, invisible, busy, not at
	// desk, etc.  Legit values are in the StatusConstants interface.
	// If you want to login as invisible, set this to STATUS_INVISIBLE
	// before you call login()
	// Note: setter is overloaded, the second version is intended for
	// use when setting custom status messages.  The boolean is true if
	// available and false if away.
	// -----------------------------------------------------------------
	public long getStatus() { return status; }

	public synchronized void setStatus(long s) 
	throws IllegalArgumentException,IOException
	{	if(sessionStatus==UNSTARTED && !(s==STATUS_AVAILABLE || s==STATUS_INVISIBLE))
			throw new IllegalArgumentException("Unstarted sessions can be available or invisible only");
		if(s==STATUS_CUSTOM)
			throw new IllegalArgumentException("Cannot set custom state without message");
		status=s;  customStatusMessage=null;  _doStatus();
	}

	public synchronized void setStatus(String m,boolean b)
	throws IllegalArgumentException,IOException
	{	if(sessionStatus==UNSTARTED)
			throw new IllegalArgumentException("Unstarted sessions can be available or invisible only");
		if(m==null)  throw new IllegalArgumentException("Cannot set custom state with null message");
		status=STATUS_CUSTOM;  
		customStatusMessage=m;  customStatusBusy=b;  _doStatus();
	}
	
	private void _doStatus() throws IllegalStateException,IOException
	{	if(status==STATUS_AVAILABLE)  transmitIsBack();
		else if(status==STATUS_CUSTOM)  transmitIsAway(customStatusMessage,customStatusBusy);
		else  transmitIsAway();
	}

	public String getCustomStatusMessage() { return customStatusMessage; }
	public boolean isCustomBusy() { return customStatusBusy; }
	
	// -----------------------------------------------------------------
	// Get and set current identity
	// -----------------------------------------------------------------
	public void setIdentity(String id) throws IllegalArgumentException
	{	for(int i=0;i<identities.length;i++)
			if(id.equals(identities[i])) { effectiveID=id;  return; }
		throw new IllegalArgumentException("Not a valid identity");
	}

	public String getIdentity() { return effectiveID; }
	
	public String[] getIdentities()
	{	return (String[])identities.clone();
	}

	// -----------------------------------------------------------------
	// Add/remove source AWT text component to use for TYPING packets
	// sent to the specified user.
	// -----------------------------------------------------------------
	public void addTypingNotification(String user,Component com)
	{	if(com==null)  return;
		synchronized(typingNotifiers)
		{	if(typingNotifiers.containsKey(user)) return;  // Aleady registered
			typingNotifiers.put(user,new TypingNotifier(com,user));
			typingNotifiers.remove(user);
		}
	}

	public void removeTypingNotification(String user)
	{	synchronized(typingNotifiers)
		{	TypingNotifier tn = (TypingNotifier)typingNotifiers.get(user);
			if(tn==null)  return;
			tn.quit=true;  tn.interrupt();
		}
	}
	
	// -----------------------------------------------------------------
	// Return lists for friends tree menu
	// -----------------------------------------------------------------
	public YahooGroup[] getGroups() { return (YahooGroup[])groups.clone(); }
	public Hashtable getUsers() { return (Hashtable)users.clone(); }
	public void refreshFriends() throws IOException { transmitList(); }
	public String getImvironment() { return imvironment; }

	// -----------------------------------------------------------------
	// Conference code
	// -----------------------------------------------------------------
	public String createConference(String[] users,String msg)
	throws IllegalStateException,IOException
	{	checkStatus();
		String r = getConferenceName();
		transmitConfInvite(users,r,msg);
		return r;
	}
	
	public void acceptConferenceInvite(String room)
	throws IllegalStateException,IOException,NoSuchConferenceException
	{	checkStatus();  transmitConfLogon(room);
	}
	
	public void declineConferenceInvite(String room,String msg)
	throws IllegalStateException,IOException,NoSuchConferenceException
	{	checkStatus();  transmitConfDecline(room,msg);
	}
	
	public void extendConference(String room,String user,String msg)
	throws IllegalStateException,IOException,NoSuchConferenceException
	{	checkStatus();  transmitConfAddInvite(user,room,msg);
	}
	
	public void sendConferenceMessage(String room,String msg)
	throws IllegalStateException,IOException,NoSuchConferenceException
	{	checkStatus();  transmitConfMsg(room,msg);
	}
	
	public void leaveConference(String room)
	throws IllegalStateException,IOException,NoSuchConferenceException
	{	checkStatus();  transmitConfLogoff(room);
	}

	// -----------------------------------------------------------------
	// Friends code
	// -----------------------------------------------------------------
	public void addFriend(String friend,String group)
	throws IllegalStateException,IOException
	{	checkStatus();  transmitFriendAdd(friend,group);
	}

	public void removeFriend(String friend,String group)
	throws IllegalStateException,IOException
	{	checkStatus();  transmitFriendRemove(friend,group);
	}
	
	public void rejectContact(String friend,String msg)
	throws IllegalStateException,IOException
	{	checkStatus();  transmitContactReject(friend,msg);
	}

	public void ignoreContact(String friend,boolean ignore)
	throws IllegalStateException,IOException
	{	checkStatus();  transmitContactIgnore(friend,ignore);
	}
	
	// -----------------------------------------------------------------
	// File transfer
	// 'save as' saves to a particular directory and filename, 'save to' 
	// uses the file's own name and saves it to a particular directory.  
	// Note: the 'to' method gets its filename from different sources.
	// Initially the URL filename (minus the path), however the header
	// Content-Disposition will override this.  The 'as' method always uses 
	// its own specified filename.  If both _path_ and _filename_ are not
	// null then the saveFT() method assumes 'to'... but if _path_ is null,
	// saveFT() assumes 'as' and _filename_ is the entire path+filename.
	// -----------------------------------------------------------------
	public void sendFileTransfer(String user,String filename,String msg)
	throws FailedFileTransferException,IOException
	{	transmitFileTransfer(user,msg,filename);
	}

	public void saveFileTransferAs(SessionFileTransferEvent ev,String filename)
	throws FailedFileTransferException,IOException
	{	saveFT(ev,null,filename);
	}
	
	public void saveFileTransferTo(SessionFileTransferEvent ev,String dir)
	throws FailedFileTransferException,IOException
	{	// -----Yahoo encodes the filename into the URL, but allow for 
		// -----Content-Disposition header override.
		if(!dir.endsWith(File.separator))  dir=dir+File.separator;
		saveFT(ev,dir,ev.getFilename());
	}

	private void saveFT(SessionFileTransferEvent ev,String path,String filename)
	throws FailedFileTransferException,IOException
	{	int len;
		byte[] buff = new byte[4096];
		String contDisp = "Content-Disposition: filename=";
	
		// -----HTTP request
		HTTPConnection conn = new HTTPConnection("GET",ev.getLocation());
		conn.println("Host: "+ev.getLocation().getHost());
		conn.println("User-Agent: "+USER_AGENT);
		conn.println("Cookie: "+cookieY+"; "+cookieT);
		conn.println("");
		conn.flush();
		
		// -----Response header
		String in = conn.readLine();
		if(in.indexOf(" 200 ")<0)  throw new FailedFileTransferException("Server HTTP error code: "+in);
		do
		{	in=conn.readLine();
			// -----Change the filename if C-D. header?
			if(path!=null && in!=null && in.startsWith(contDisp))
			{	filename=in.substring(contDisp.length());
				// -----Strip quotes if necessary
				if(filename.charAt(0)=='\"')
					filename=filename.substring(1,filename.length()-1);
			}
		}while(in!=null && in.trim().length()>0);
		if(in==null)  throw new FailedFileTransferException("Server premature end of reply");
		// -----Response body
		if(path!=null)  filename=path+filename;
		DataOutputStream dos = new DataOutputStream(new FileOutputStream(filename));
		do
		{	len = conn.read(buff);
			if(len>0)  dos.write(buff,0,len);
		}while(len>=0);
		dos.flush();  dos.close();
		conn.close();
	}
	
	// -----------------------------------------------------------------
	// Test - ignore these (used as hooks for test client)
	// -----------------------------------------------------------------
	public void __test1()
	{	
	}
	public void __test2()
	{	
	}


	// -----------------------------------------------------------------
	// Transmit an AUTH packet, as a way of introduction to the server
	// -----------------------------------------------------------------
	protected void transmitAuth() throws IOException
	{	sessionStatus=AUTH;  				// Set status
		PacketBodyBuffer body = new PacketBodyBuffer();
		body.addElement("0",username);  // FIX: added for HTTPConnectionHandler
		body.addElement("1",username);  // FIX: effective id?
		sendPacket(body,SERVICE_AUTH);						// 0x57
	}

	// -----------------------------------------------------------------
	// Transmit an AUTHRESP packet, the second part of our login process
	// plp - plain response (not MD5Crypt'd)
	// crp - crypted response (MD5Crypt'd)
	// -----------------------------------------------------------------
	protected void transmitAuthResp(String plp,String crp) throws IOException
	{	PacketBodyBuffer body = new PacketBodyBuffer();
		body.addElement("0" ,username);
		body.addElement("6" ,plp);
		body.addElement("96",crp);
		body.addElement("2" ,"1");
		body.addElement("1" ,effectiveID);
		sendPacket(body,SERVICE_AUTHRESP);					// 0x54
	}

	// -----------------------------------------------------------------
	// Transmit an CONFADDINVITE packet.  We send one of these when we 
	// wish to invite more users to our conference.
	// -----------------------------------------------------------------
	protected void transmitConfAddInvite(String user,String room,String msg) 
	throws IOException,NoSuchConferenceException
	{	// -----Check this conference actually exists (throws exception if not)
		getConference(room);
		// -----Send new invite packet to Yahoo
		PacketBodyBuffer body = new PacketBodyBuffer();
		body.addElement("1",effectiveID);
		body.addElement("51",user);
		body.addElement("57",room);
		body.addElement("58",msg);
		body.addElement("13","0");  // FIX : what's this for?
		sendPacket(body,SERVICE_CONFADDINVITE);				// 0x1c
	}

	// -----------------------------------------------------------------
	// Transmit an CONFDECLINE packet.  We send one of these when we 
	// decline an offer to join a conference.
	// -----------------------------------------------------------------
	protected void transmitConfDecline(String room,String msg) 
	throws IOException,NoSuchConferenceException
	{	// -----Flag this conference as now dead
		YahooConference yc = getConference(room);  yc.closeConference();
		Vector users = yc.getUsers();
		// -----Send decline packet to Yahoo
		PacketBodyBuffer body = new PacketBodyBuffer();
		body.addElement("1",effectiveID);
		for(int i=0;i<users.size();i++)
			body.addElement("3",(String)users.elementAt(i));
		body.addElement("57",room);
		body.addElement("14",msg);
		sendPacket(body,SERVICE_CONFDECLINE);				// 0x1a
	}

	// -----------------------------------------------------------------
	// Transmit an CONFLOGOFF packet.  We send one of these when we wish
	// to leave a conference.
	// -----------------------------------------------------------------
	protected void transmitConfLogoff(String room)
	throws IOException,NoSuchConferenceException
	{	// -----Flag this conference as now dead
		YahooConference yc = getConference(room);  yc.closeConference();		
		Vector users = yc.getUsers();
		// -----Send decline packet to Yahoo
		PacketBodyBuffer body = new PacketBodyBuffer();
		body.addElement("1",effectiveID);
		for(int i=0;i<users.size();i++)
			body.addElement("3",(String)users.elementAt(i));
		body.addElement("57",room);
		sendPacket(body,SERVICE_CONFLOGOFF);				// 0x1b
	}

	// -----------------------------------------------------------------
	// Transmit an CONFLOGON packet.  Send this when we want to accept
	// an offer to join a conference conference.
	// -----------------------------------------------------------------
	protected void transmitConfLogon(String room)
	throws IOException,NoSuchConferenceException
	{	// -----Get a list of users for this conference
		Vector users = getConference(room).getUsers();
		// -----Send accept packet to Yahoo
		PacketBodyBuffer body = new PacketBodyBuffer();
		body.addElement("1",effectiveID);
		for(int i=0;i<users.size();i++)  
			body.addElement("3",(String)users.elementAt(i));
		body.addElement("57",room);
		sendPacket(body,SERVICE_CONFLOGON);					// 0x19
	}

	// -----------------------------------------------------------------
	// Transmit an CONFMSG packet.  We send one of these when we wish
	// to send a message to a conference.
	// -----------------------------------------------------------------
	protected void transmitConfMsg(String room,String msg)
	throws IOException,NoSuchConferenceException
	{	// -----Get a list of users for this conference
		Vector users = getConference(room).getUsers();
		// -----Send message packet to yahoo
		PacketBodyBuffer body = new PacketBodyBuffer();
		body.addElement("1",effectiveID);
		for(int i=0;i<users.size();i++)
			body.addElement("53",(String)users.elementAt(i));
		body.addElement("57",room);
		body.addElement("14",msg);
		if(Util.isUtf8(msg))  body.addElement("97","1");
		sendPacket(body,SERVICE_CONFMSG);					// 0x1d	
	}

	// -----------------------------------------------------------------
	// Transmit an CONFINVITE packet.  This is sent when we want to
	// create a new conference, with the specified users and with a
	// given welcome message.
	// -----------------------------------------------------------------
	protected void transmitConfInvite(String[] users,String room,String msg) throws IOException
	{	// -----Create a new conference object
		conferences.put(room,new YahooConference(room,identities));
		// -----Send request to Yahoo
		PacketBodyBuffer body = new PacketBodyBuffer();
		body.addElement("1",effectiveID);
		body.addElement("50",username);
		for(int i=0;i<users.length;i++)  body.addElement("52",users[i]);
		body.addElement("57",room);
		body.addElement("58",msg);
		body.addElement("13","0");  // FIX: what's this for?
		sendPacket(body,SERVICE_CONFINVITE);				// 0x1c
	}

	// -----------------------------------------------------------------
	// Transmit an CONTACTIGNORE packet.  We would do this in response to 
	// an ADDFRIEND packet arriving. (???)
	// FIX: when does this get sent?
	// -----------------------------------------------------------------
	protected void transmitContactIgnore(String friend,boolean ignore) throws IOException
	{	PacketBodyBuffer body = new PacketBodyBuffer();
		body.addElement("1" ,username); // FIX: effective id?
		body.addElement("7" ,friend);
		if(ignore)	body.addElement("13","1");  // Bug: 1/2 not 0/1 ???
			else  body.addElement("13","2");
		sendPacket(body,SERVICE_CONTACTIGNORE);				// 0x85
	}

	// -----------------------------------------------------------------
	// Transmit a CONTACTREJECT packet.  We would do this when we wish
	// to overrule an attempt to add us as a friend (when we get a
	// ADDFRIEND packet!)
	// -----------------------------------------------------------------
	protected void transmitContactReject(String friend,String msg) throws IOException
	{	PacketBodyBuffer body = new PacketBodyBuffer();
		body.addElement("1" ,username); // FIX: effective id?
		body.addElement("7" ,friend);
		body.addElement("14",msg);
		sendPacket(body,SERVICE_CONTACTREJECT);				// 0x86
	}

	// -----------------------------------------------------------------
	// Transmit a FILETRANSFER packet, to send a binary file to a friend.
	// -----------------------------------------------------------------
	protected void transmitFileTransfer(String to,String message,String filename)
	throws FailedFileTransferException,IOException
	{	String cookie = cookieY+"; "+cookieT;
		int fileSize=-1;
		byte[] packet;
		byte[] marker = { '2','9',(byte)0xc0,(byte)0x80 };
		
		// -----Load binary from file
		DataInputStream dis = new DataInputStream(new FileInputStream(filename));
		fileSize=dis.available();
		if(fileSize<=0)  
			throw new FailedFileTransferException("File transfer: missing or empty file");
		byte[] fileData = new byte[fileSize];
		dis.readFully(fileData);  dis.close();

		// -----Create a Yahoo packet into 'packet'
		PacketBodyBuffer body = new PacketBodyBuffer();
		body.addElement("0" ,username);
		body.addElement("5" ,to);
		body.addElement("28",fileSize+"");
		body.addElement("27",new File(filename).getName());
		body.addElement("14",message);
		packet = body.getBuffer();
		
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		DataOutputStream dos = new DataOutputStream(baos);
		dos.write(MAGIC,0,4);  dos.write(VERSION,0,4);
		dos.writeShort((packet.length+4) & 0xFFFF);
		dos.writeShort(SERVICE_FILETRANSFER & 0xFFFF);
		dos.writeInt((int)(status & 0xFFFFFFFF));
		dos.writeInt((int)(sessionId & 0xFFFFFFFF));
		dos.write(packet,0,packet.length);
		dos.write(marker,0,4);  // Extra 4 bytes : marker before file data (?)		

		packet = baos.toByteArray();
		
		// -----Send to Yahoo using POST
		HTTPConnection conn = new HTTPConnection("POST",new URL(FILE_TF_URL));
		conn.println("Content-Length: "+(fileSize+packet.length));
		conn.println("User-Agent: "+USER_AGENT);
		conn.println("Host: "+FILE_TF_HOST);
		conn.println("Cookie: "+cookie);
		conn.println("");
		conn.write(packet);									// 0x46
		conn.write(fileData);
		conn.flush();
		
		// -----Read HTTP header
		String in = conn.readLine() , head=in;
		if(in!=null)
		{	byte[] buffer = new byte[4096];			// FIX: this code just gobbles
			while(conn.read(buffer)>0);				// bytes - should read and parse!
		}
		/*while(in!=null && in.trim().length>0)  in=conn.readLine();
		// -----Body
		byte[] buff = new byte[4];  
		int len = conn.read(buff);
		String packHead=="";
		if(len>0 && buff[0]>0)
		{	len = conn.read(buff);  // YHOO=fail, YMSG=success (?)
			packHead=(char)buff[0]+(char)buff[1]+(char)buff[2]+(char)buff[3];
		}  // FIX - should read rest of header
		*/		
		conn.close();
		if(head.indexOf(" 200 ")<0)
			throw new FailedFileTransferException("Server rejected upload");
	}

	// -----------------------------------------------------------------
	// Transmit a FRIENDADD packet.  If all goes well we'll get a
	// FRIENDADD packet back with the details of the friend to confirm
	// the transation (usually preceeded by a CONTACTNEW packet with
	// well detailed info).
	// friend - Yahoo id of friend to add
	// group - Group to add it to
	// -----------------------------------------------------------------
	protected void transmitFriendAdd(String friend,String group) throws IOException
	{	PacketBodyBuffer body = new PacketBodyBuffer();
		body.addElement("1" ,username);  // FIX: effective id?
		body.addElement("7" ,friend);
		body.addElement("65",group);
		sendPacket(body,SERVICE_FRIENDADD);					// 0x83
	}

	// -----------------------------------------------------------------
	// Transmit a FRIENDREMOVE packet.  We should get a FRIENDREMOVE
	// packet back (usually preceeded by a CONTACTNEW packet).
	// friend - Yahoo id of friend to remove
	// group - Group to remove it from
	// -----------------------------------------------------------------
	protected void transmitFriendRemove(String friend,String group) throws IOException
	{	PacketBodyBuffer body = new PacketBodyBuffer();
		body.addElement("1" ,username);  // FIX: effective id?
		body.addElement("7" ,friend);
		body.addElement("65",group);
		sendPacket(body,SERVICE_FRIENDREMOVE);				// 0x84
	}

	// -----------------------------------------------------------------
	// Transmit a GROUPRENAME packet, to change the name of one of our
	// friends groups.
	// -----------------------------------------------------------------
	protected void transmitGroupRename(String oldName,String newName) throws IOException
	{	PacketBodyBuffer body = new PacketBodyBuffer();
		body.addElement("1" ,username);  // FIX: effective id?
		body.addElement("65",oldName);
		body.addElement("67",newName);
		sendPacket(body,SERVICE_GROUPRENAME);				// 0x13
	}

	// -----------------------------------------------------------------
	// Transmit a IDACT packet.
	// -----------------------------------------------------------------
	protected void transmitIdAct(String id) throws IOException
	{	PacketBodyBuffer body = new PacketBodyBuffer();
		body.addElement("3",id);
		sendPacket(body,SERVICE_IDACT);						// 0x07
	}
	
	// -----------------------------------------------------------------
	// Transmit a IDDEACT packet.
	// -----------------------------------------------------------------
	protected void transmitIdDeact(String id) throws IOException
	{	PacketBodyBuffer body = new PacketBodyBuffer();
		body.addElement("3",id);
		sendPacket(body,SERVICE_IDDEACT);					// 0x08
	}

	// -----------------------------------------------------------------
	// Transmit an IDLE packet.  Used by the HTTP proxy connection to
	// provide a mechanism were by incoming packets can be delivered.  An
	// idle packet is sent every thirty seconds (as part of a HTTP POST) 
	// and the server responds with all the packets accumulated since last 
	// contact. 
	// -----------------------------------------------------------------
	protected void transmitIdle() throws IOException
	{	PacketBodyBuffer body =  new PacketBodyBuffer();
		body.addElement("1",effectiveID);
		body.addElement("0",username);
		sendPacket(body,SERVICE_IDLE);						// 0x05
	}

	// -----------------------------------------------------------------
	// Transmit an ISAWAY packet.  To return, try transmiting an ISBACK 
	// packet!  Comes in two flavours: custom message and regular
	// -----------------------------------------------------------------
	protected void transmitIsAway() throws IOException
	{	PacketBodyBuffer body = new PacketBodyBuffer();
		body.addElement("10",status+"");
		sendPacket(body,SERVICE_ISAWAY,status);				// 0x03
	}

	protected void transmitIsAway(String msg,boolean a) throws IOException
	{	PacketBodyBuffer body = new PacketBodyBuffer();
		status=STATUS_CUSTOM;
		body.addElement("10",status+"");
		body.addElement("19",msg);
		if(a) body.addElement("47","1");  // 1=away
			else body.addElement("47","0");  // 0=back
		sendPacket(body,SERVICE_ISAWAY,status);				// 0x03
	}

	// -----------------------------------------------------------------
	// Transmit an ISBACK packet, contains no body, just the Yahoo status.
	// We should send this to return from an ISAWAY, or after we have 
	// confirmed a sucessful LOGON - it sets our initial status (visibility) 
	// to the outside world.  Typical initial values for 'status' are 
	// AVAILABLE and INVISIBLE.
	// -----------------------------------------------------------------
	protected void transmitIsBack() throws IOException
	{	PacketBodyBuffer body = new PacketBodyBuffer();
		body.addElement("10",status+"");
		sendPacket(body,SERVICE_ISBACK,status);				// 0x04
	}

	// -----------------------------------------------------------------
	// Transmit a LIST packet.
	// -----------------------------------------------------------------
	protected void transmitList() throws IOException
	{	PacketBodyBuffer body = new PacketBodyBuffer();
		body.addElement("1",username);  // FIX: effective id?
		sendPacket(body,SERVICE_LIST);
	}

	// -----------------------------------------------------------------
	// Transmit a LOGOFF packet, which should exit us from Yahoo IM.
	// -----------------------------------------------------------------
	protected void transmitLogoff() throws IOException
	{	PacketBodyBuffer body = new PacketBodyBuffer();
		sendPacket(body,SERVICE_LOGOFF);					// 0x02		
	}

	// -----------------------------------------------------------------
	// Transmit a MESSAGE packet.
	// to - the Yahoo ID of the user to send the message to
	// msg - the text of the message
	// -----------------------------------------------------------------
	protected void transmitMessage(String to,String msg) throws IOException
	{	// -----Send packet
		PacketBodyBuffer body = new PacketBodyBuffer();
		body.addElement("0" ,username);
		body.addElement("1" ,effectiveID);
		body.addElement("5" ,to);
		body.addElement("14",msg);
		// -----Extension for YMSG9
		if(Util.isUtf8(msg))  body.addElement("97","1");
		body.addElement("63",imvironment+";"); // Not supported here!
		body.addElement("64","0");	
		sendPacket(body,SERVICE_MESSAGE,STATUS_OFFLINE);	// 0x06
		// -----If we have a typing notifier, inform it the typing has ended
		TypingNotifier tn = (TypingNotifier)typingNotifiers.get(to);
		if(tn!=null)  tn.stopTyping();
	}

	// -----------------------------------------------------------------
	// Transmit a NOTIFY packet.  Could be used for all sorts of purposes,
	// but mainly games and typing notifications.  Only typing is supported 
	// by this API.  The mode determines the type of notification, "TYPING"
	// or "GAME"; msg holds the game name (or a single space if typing).
	// -----------------------------------------------------------------
	protected void transmitNotify(String friend,boolean on,String msg,String mode) throws IOException
	{	PacketBodyBuffer body = new PacketBodyBuffer();
		body.addElement("4",effectiveID);
		body.addElement("5",friend);
		body.addElement("14",msg);
		if(on)  body.addElement("13","1");
			else  body.addElement("13","0");
		body.addElement("49",mode);
		sendPacket(body,SERVICE_NOTIFY,STATUS_TYPING);		// 0x4b
	}
	
	// -----------------------------------------------------------------
	// Transmit a PING packet.
	// -----------------------------------------------------------------
	protected void transmitPing() throws IOException
	{	PacketBodyBuffer body = new PacketBodyBuffer();
		sendPacket(body,SERVICE_PING);						// 0x12
	}

	// -----------------------------------------------------------------
	// Transmit a USERSTAT packet.  Purpose?  Unknown  :-)
	// -----------------------------------------------------------------
	protected void transmitUserStat() throws IOException	// 0x0a
	{	PacketBodyBuffer body = new PacketBodyBuffer();
		sendPacket(body,SERVICE_USERSTAT);
	}
			


	// -----------------------------------------------------------------
	// Process an incoming ADDIGNORE packet.  We get one of these when we 
	// ignore/unignore someone, although their purpose is unknown as
	// Yahoo follows up with a CONTACTIGNORE packet.  The only disting-
	// uising feature is the latter is always sent, wereas this packet 
	// is only sent if there's an actual change in ignore status.  The
	// packet's payload appears to always be empty.
	// -----------------------------------------------------------------
	protected void receiveAddIgnore(YMSG9Packet pkt)		// 0x11
	{	// No implementation (yet!)
	}

	// -----------------------------------------------------------------
	// Process an incoming AUTH packet (in response to the AUTH packet
	// we transmitted to the server).
	// Format: "1" <username> "94" <challenge string (24 chars)>
	// -----------------------------------------------------------------
	protected void receiveAuth(YMSG9Packet pkt) 			// 0x57
	throws IOException,NoSuchAlgorithmException
	{	String[] s;
		try
		{	s=ChallengeResponse.getStrings(username,password,pkt.getValue("94"));
		}
		catch(NoSuchAlgorithmException e) { throw e; }
		catch(Exception e) { throw new YMSG9BadFormatException("auth",false); }
		transmitAuthResp(s[0],s[1]);
	}

	// -----------------------------------------------------------------
	// Process an incoming AUTHRESP packet.  If we get one of these it
	// means the logon process has failed.  Set the session state to be
	// failed, and flag the end of login.
	// Note: we don't throw exceptions on the input thread, but instead 
	// we pass them to the thread which called login()
	// -----------------------------------------------------------------
	protected void receiveAuthResp(YMSG9Packet pkt)			// 0x54
	{	try
		{	if(pkt.getValue("66")!=null)
			{	long l = Long.parseLong(pkt.getValue("66"));
				if(l==STATUS_LOCKED)	// Account locked out?
				{	URL u;
					try { u = new URL(pkt.getValue("20")); } catch(Exception e) { u=null; }
					loginException = new AccountLockedException("User "+username+" has been locked out",u);
				}
				else if(l==STATUS_BAD)	// Bad login (password?)
				{	loginException = new LoginRefusedException("User "+username+" refused login");
				}
			}
		}catch(NumberFormatException e) {}
		// -----Notify login() calling thread of failure
		sessionStatus=FAILED;  loginOver=true;		
	}

	// -----------------------------------------------------------------
	// Process an incoming CONFINVITE packet.  We get one of these when
	// we are being invited to join someone else's existing conference.
	// To all intent and purpose this (I assume) is the same as a
	// regular invite packet, except it is only delievered on on source,
	// not everone on the list (?)
	// -----------------------------------------------------------------
	protected void receiveConfAddInvite(YMSG9Packet pkt)	// 0x01c
	{	receiveConfInvite(pkt);
	}

	// -----------------------------------------------------------------
	// Process an incoming CONFINVITE packet.  We get one of these when
	// we are being invited to join someone else's conference.  Note:
	// it is possible for conference packets (ie: logon) can arrive before 
	// the invite.  These are buffered until the invite is received.
	// -----------------------------------------------------------------
	protected void receiveConfInvite(YMSG9Packet pkt)		// 0x18
	{	try
		{	SessionConferenceEvent se = new SessionConferenceEvent
			(	this,
				pkt.getValue("1"),							// to (effective id)
				pkt.getValue("50"),							// from
				pkt.getValue("58"),							// message (topic)
				pkt.getValue("57"),							// room
				pkt.getValues("52")							// users array
			);
			// -----Add the users
			YahooConference yc = getOrCreateConference(se.getRoom());
			yc.addUsers(se.getUsers());  yc.addUser(se.getFrom());
			// -----Fire invite event
			if(!yc.isClosed())  // Should never be closed fir invite!
				new FireEvent().fire(se,SERVICE_CONFINVITE);
			// -----Set invited status and work through buffered conference
			synchronized(yc)
			{	Vector v = yc.inviteReceived();
				for(int i=0;i<v.size();i++)
					ipThread.process((YMSG9Packet)v.elementAt(i));
			}
		}catch(Exception e) { throw new YMSG9BadFormatException("conference invite",false); }
	}
	
	// -----------------------------------------------------------------
	// Process an incoming CONFLOGOFF packet.  We get one of these when
	// someone leaves the conference.  Note: in *very* extreme circum-
	// stances, this may arrive before the invite packet.
	// -----------------------------------------------------------------
	protected void receiveConfLogoff(YMSG9Packet pkt)		// 0x1b
	{	// -----If we have not received an invite yet, buffer packets
		YahooConference yc = getOrCreateConference(pkt.getValue("57"));
		synchronized(yc)
		{	if(!yc.isInvited()) { yc.addPacket(pkt);  return; }
		}
		// -----Otherwise, handle the packet
		try
		{	SessionConferenceEvent se = new SessionConferenceEvent
			(	this,
				pkt.getValue("1"),							// to (effective id)
				pkt.getValue("56"),							// from
				null,										// message
				pkt.getValue("57")							// room
			);
			// -----Remove the user
			yc.removeUser(se.getFrom());
			// -----Fire invite event
			if(!yc.isClosed())  // Should never be closed fir invite!
				new FireEvent().fire(se,SERVICE_CONFLOGOFF);
		}catch(Exception e) { throw new YMSG9BadFormatException("conference logoff",false); }
	}

	// -----------------------------------------------------------------
	// Process an incoming CONFLOGON packet.  We get one of these when
	// someone joins a conference we have been invited to (even if we
	// ourselves have yet to accept/decline).  Note: in extreme circum-
	// stances, this may arrive before the invite packet.
	// -----------------------------------------------------------------
	protected void receiveConfLogon(YMSG9Packet pkt)		// 0x19
	{	// -----If we have not received an invite yet, buffer packets
		YahooConference yc = getOrCreateConference(pkt.getValue("57"));
		synchronized(yc)
		{	if(!yc.isInvited()) { yc.addPacket(pkt);  return; }
		}
		// -----Otherwise, handle the packet
		try
		{	SessionConferenceEvent se = new SessionConferenceEvent
			(	this,
				pkt.getValue("1"),							// to (effective id)
				pkt.getValue("53"),							// from (accepting user)
				null,										// message
				pkt.getValue("57")							// room
			);
			// -----Add user (probably alread on list, but just to be sure!)
			yc.addUser(se.getFrom());
			// -----Fire event
			if(!yc.isClosed())
				new FireEvent().fire(se,SERVICE_CONFLOGON);
		}catch(Exception e) { throw new YMSG9BadFormatException("conference logon",false); }
	}
				
	// -----------------------------------------------------------------
	// Process an incoming CONFMSG packet.  We get one of these when 
	// someone in a conference we are part of sends a message.  Note:
	// in extreme circumstances this may arrive before the invite packet.
	// -----------------------------------------------------------------
	protected void receiveConfMsg(YMSG9Packet pkt)			// 0x1d
	{	// -----If we have not received an invite yet, buffer packets
		YahooConference yc = getOrCreateConference(pkt.getValue("57"));
		synchronized(yc)
		{	if(!yc.isInvited()) { yc.addPacket(pkt);  return; }
		}
		// -----Otherwise, handle the packet
		try
		{	SessionConferenceEvent se = new SessionConferenceEvent
			(	this,
				pkt.getValue("1"),							// to (effective id)
				pkt.getValue("3"),							// from
				pkt.getValue("14"),							// message
				pkt.getValue("57")							// room
			);
			// -----Fire event
			if(!yc.isClosed())
				new FireEvent().fire(se,SERVICE_CONFMSG);
		}catch(Exception e) { throw new YMSG9BadFormatException("conference mesg",false); }
	}

	// -----------------------------------------------------------------
	// Process an incoming CONTACTIGNORE packet. We get one of these to
	// confirm an outgoin CONTACTIGNORE - an ADDIGNORE packet may preceed
	// this, but only if the ignore status has genuinely changed state.
	// -----------------------------------------------------------------
	protected void receiveContactIgnore(YMSG9Packet pkt)	// 0x85
	{	try
		{	String n = pkt.getValue("0");
			boolean ig = pkt.getValue("13").charAt(0)=='1';
			int st = Integer.parseInt(pkt.getValue("66"));
			if(st==0)
			{	// -----Update ignore status, and fire friend changed event
				if(!users.containsKey(n))  users.put(n,new YahooUser(n));
				YahooUser yu = (YahooUser)users.get(n);
				yu.setIgnored(ig);
				// -----Fire event
				SessionFriendEvent se = new SessionFriendEvent(this,1);
				se.setYahooUser(0,yu);
				new FireEvent().fire(se,SERVICE_ISAWAY);
			}
			else
			{	// -----Error
				String m="Contact ignore error: ";
				switch(st)
				{	case 2 :	m=m+"Already on ignore list";  break;
					case 3 :	m=m+"Not currently ignored";  break;
					case 12 :	m=m+"Cannot ignore friend";  break;
					default :	m=m+"Unknown error";  break;
				}
				errorMessage(m,pkt.service);
			}
		}catch(Exception e) { throw new YMSG9BadFormatException("contact ignore",false); }
	}

	// -----------------------------------------------------------------
	// Process an incoming CONTACTNEW packet.  We get one of these: (1) when
	// someone has added us to their friends list, giving us the chance to 
	// refuse them;  (2) when we add or remove a friend (see FRIENDADD/REMOVE 
	// outgoing) as confirmation prior to the FRIENDADD/REMOVE packet being 
	// echoed back to us - if the friend is online status info may be inc-
	// luded (supposedly for multiple friends, although given the circum-
	// stances probably always contains only one!);  (3) when someone refuses 
	// a contact request (add friend) from us.
	// -----------------------------------------------------------------
	protected void receiveContactNew(YMSG9Packet pkt)		// 0x0f
	{	try
		{	if(pkt.length<=0)					// Empty packet is received after				
			{	return;							// we transmit FRIENDADD/REMOVE
			}
			else if(pkt.getValue("7")!=null)	// Ditto, except friend is online
			{	updateFriendsStatus(pkt);  return;
			}
			else if(pkt.status==0x07)			// Conact refused			
			{	SessionEvent se = new SessionEvent
				(	this,
					null,									// to
					pkt.getValue("3"),						// from
					pkt.getValue("14")						// message
				);
				new FireEvent().fire(se,SERVICE_CONTACTREJECT);
			}
			else								// Contact request
			{	SessionEvent se = new SessionEvent
				(	this,
					pkt.getValue("1"),						// to
					pkt.getValue("3"),						// from
					pkt.getValue("14"),						// message
					pkt.getValue("15")  					// timestamp
				);
				se.setStatus(pkt.status);  // status!=0 means offline message
				new FireEvent().fire(se,SERVICE_CONTACTNEW);
			}
		}catch(Exception e) { throw new YMSG9BadFormatException("contact request",false); }
	}	

	// -----------------------------------------------------------------
	// Process an incoming FILETRANSFER packet.  This packet can be
	// received under two circumstances: after a successful FT upload,
	// in which case it contains a text message with the download URL,
	// or because someone has sent us a file.  Note: TF packets do not
	// contain the file data itself, but rather a link to a tmp area on
	// Yahoo's webservers which holds the file.
	// -----------------------------------------------------------------
	protected void receiveFileTransfer(YMSG9Packet pkt)		// 0x46
	{	try
		{	if(pkt.getValue("38")==null)		// Acknowledge upload
			{	SessionEvent se = new SessionEvent
				(	this,
					pkt.getValue("5"),						// to
					pkt.getValue("4"),						// from
					pkt.getValue("14")						// message				
				);
				new FireEvent().fire(se,SERVICE_MESSAGE);
			}
			else								// Receive file transfer
			{	SessionFileTransferEvent se = new SessionFileTransferEvent
				(	this,
					pkt.getValue("5"),						// to
					pkt.getValue("4"),						// from
					pkt.getValue("14"),						// message
					pkt.getValue("38"), 					// expires				
					pkt.getValue("20")						// URL
				);
				new FireEvent().fire(se,SERVICE_FILETRANSFER);
			}
		}catch(Exception e) { throw new YMSG9BadFormatException("file transfer",false); }

	}

	// -----------------------------------------------------------------
	// Process an incoming FRIENDADD packet.  We get one of these after
	// we've sent a FRIENDADD packet, as confirmation.  It contains
	// basic details of our new friend, although it seems a bit redundant
	// as Yahoo sents a CONTACTNEW with these details before this packet.
	// -----------------------------------------------------------------
	protected void receiveFriendAdd(YMSG9Packet pkt)		// 0x83
	{	try
		{	// -----We probably got a CONTACTNEW with before we got this packet, 
			// -----so check if the user hasn't already been created in users hash
			// -----(if not, create!) then add to groups structure.
			String n=pkt.getValue("7") , s=pkt.getValue("66") , g=pkt.getValue("65");
			if(!users.containsKey(n)) 
				users.put(n,new YahooUser(n,s,"0","0"));
			YahooUser yu = (YahooUser)users.get(n);
			insertFriend(yu,g);
			// -----Fire event : 7=friend, 66=status, 65=group name
			SessionFriendEvent se = new SessionFriendEvent(this,yu,g);
			new FireEvent().fire(se,SERVICE_FRIENDADD);
		}catch(Exception e) { throw new YMSG9BadFormatException("friend added",false); }
	}

	// -----------------------------------------------------------------
	// Process an incoming FRIENDADD packet.  We get one of these after
	// we've sent a FRIENDREMOVE packet, as confirmation.  It contains
	// basic details of the friend we've deleted.
	// -----------------------------------------------------------------
	protected void receiveFriendRemove(YMSG9Packet pkt)		// 0x84
	{	try
		{	String n=pkt.getValue("7") , g=pkt.getValue("65");
			YahooUser yu = (YahooUser)users.get(n);
			if(yu==null) { report("Unknown friend",pkt);  return; }
			deleteFriend(yu,g);
			// -----Fire event : 7=friend, 66=status, 65=group name
			SessionFriendEvent se = new SessionFriendEvent(this,yu,g);
			new FireEvent().fire(se,SERVICE_FRIENDREMOVE);
		}catch(Exception e) { throw new YMSG9BadFormatException("friend removed",false); }
	}

	// -----------------------------------------------------------------
	// Process an incoming IDACT packet.
	// -----------------------------------------------------------------
	protected void receiveIdAct(YMSG9Packet pkt)			// 0x07
	{	// FIX: do something here!
	}		

	// -----------------------------------------------------------------
	// Process an incoming ISAWAY packet.  See ISBACK below.
	// -----------------------------------------------------------------
	protected void receiveIsAway(YMSG9Packet pkt)			// 0x03
	{	// -----If this an update to a friend?
		if(pkt.getValue("7")!=null)
		{	updateFriendsStatus(pkt);
		}
	}

	// -----------------------------------------------------------------
	// Process an incoming ISBACK packet.  God alone knows what I'm supposed
	// to do with this when the payload is empty!!
	// -----------------------------------------------------------------
	protected void receiveIsBack(YMSG9Packet pkt)			// 0x04
	{	if(pkt.getValue("7")!=null)
		{	updateFriendsStatus(pkt);
		}
	}

	// -----------------------------------------------------------------
	// Process and incoming LIST packet.  We'll typically get one of these
	// when our logon is sucessful.  (It should arrive before the LOGON 
	// packet)
	// -----------------------------------------------------------------
	protected void receiveList(YMSG9Packet pkt)				// 0x55
	{	// -----Friends list, each group is encoded as the group name
		// -----(ie: "Friends") followed by a colon, followed by a comma
		// -----separated list of friend ids, followed by a single \n (0x0a).
		try
		{	String s = pkt.getValue("87");		// Value for key "87"
			if(s!=null)
			{	StringTokenizer st1 = new StringTokenizer(s,"\n");
				groups = new YahooGroup[st1.countTokens()];
				int i=0;
				while(st1.hasMoreTokens())
				{	// -----Extract group
					String s1 = st1.nextToken();
					// -----Store group name and decoded friends list
					groups[i] = new YahooGroup( s1.substring(0,s1.indexOf(":")) );
					StringTokenizer st2 = new StringTokenizer( s1.substring(s1.indexOf(":")+1),"," );
					while(st2.hasMoreTokens())
					{	YahooUser yu;
						String k = st2.nextToken();
						// -----Same user can appear in more than one group
						if(users.containsKey(k)) { yu = (YahooUser)users.get(k); }
							else { yu = new YahooUser(k);  users.put(yu.getId(),yu); }
						// -----Add to group
						groups[i].addElement(yu);
					}
					i++;
				}
			}								
		}catch(Exception e) { throw new YMSG9BadFormatException("friends list in list",false); }

		// -----Ignored list (people we don't want to hear from!)
		try
		{	String s = pkt.getValue("88");		// Value for key "88"
			if(s!=null)
			{	// -----Comma separated list (?)
				StringTokenizer st = new StringTokenizer(s,",");
				while(st.hasMoreTokens())
				{	s=st.nextToken();
					if(!users.containsKey(s))  users.put(s,new YahooUser(s));
					YahooUser yu = (YahooUser)users.get(s);
					yu.setIgnored(true);
				}
			}							
		}catch(Exception e) { throw new YMSG9BadFormatException("ignored list in list",false); }

		// -----Identities list (alternative yahoo ids we can use!)
		try
		{	String s = pkt.getValue("89");		// Value for key "89"
			if(s!=null)
			{	// -----Comma separated list (?)
				StringTokenizer st = new StringTokenizer(s,",");
				int i=0;
				identities = new String[st.countTokens()];
				while(st.hasMoreTokens())
					identities[i++] = st.nextToken();
			}							
		}catch(Exception e) { throw new YMSG9BadFormatException("identities list in list",false); }

		// -----Yahoo gives us three cookies, Y, T and C
		try
		{	String[] ck = ConnectionHandler.extractCookies(pkt);
			cookieY=ck[ConnectionHandler.Y_COOKIE]; 	// Y=<cookie>
			cookieT=ck[ConnectionHandler.T_COOKIE];		// T=<cookie>
			cookieC=ck[ConnectionHandler.C_COOKIE];		// C=<cookie>
		}catch(Exception e) { throw new YMSG9BadFormatException("cookies in list",false); }

		// -----If this was sent outside the login process is over, send an event
		if(loginOver)  new FireEvent().fire(new SessionEvent(this),SERVICE_LIST);
	}	

	// -----------------------------------------------------------------
	// Process an incoming LOGOFF packet.  If we get one of these it means
	// Yahoo wants to throw us off the system.  When logging in using the 
	// same Yahoo ID using a second client, I noticed the Yahoo server sent
	// me one of these, and closed the socket.
	// -----------------------------------------------------------------
	protected void receiveLogoff(YMSG9Packet pkt)			// 0x02
	{	// -----Is this packet about us, or one of our online friends?
		if(pkt.getValue("7")==null)				// About us
		{	sessionStatus = UNSTARTED;  killThreads();
			new FireEvent().fire(new SessionEvent(this),SERVICE_LOGOFF);
		}
		else									// About friends
		{	// -----Process optional section, friends going offline
			try
			{	updateFriendsStatus(pkt);
			}catch(Exception e) { throw new YMSG9BadFormatException("online friends in logoff",false); }
		}
	}

	// -----------------------------------------------------------------
	// Process an incoming LOGON packet.  If we get one of these it means
	// the logon process has been successful.  If the user has friends
	// already online, an extra section of varying length is appended,
	// starting with a count, and then detailing each friend in turn.
	// -----------------------------------------------------------------
	protected void receiveLogon(YMSG9Packet pkt)			// 0x01
	{	// -----Is this packet about us, or one of our online friends?
		if(pkt.getValue("7")!=null)
		{	// -----Process optional section, friends currently online
			try
			{	updateFriendsStatus(pkt);
			}catch(Exception e) { throw new YMSG9BadFormatException("online friends in logon",false); }
		}
		// -----Still logging in?
		if(!loginOver)
		{	try { transmitIsBack(); }catch(IOException e) {}
			sessionStatus=MESSAGING;  loginOver=true;
		}
	}

	// -----------------------------------------------------------------
	// Process an incoming MESSAGE packet.  Message can be either online
	// or offline, the latter having a datestamp of when they were sent.
	// -----------------------------------------------------------------
	protected void receiveMessage(YMSG9Packet pkt)			// 0x06
	{	try
		{	if(pkt.getValue("14")==null)		// Contains no message?
			{	return;
			}
			else if(pkt.status==STATUS_NOTINOFFICE)	// Sent while we were offline
			{	int i=0;
				// -----Read each message, until null
				String s = pkt.getNthValue("31",i);
				while(s!=null)
				{	SessionEvent se = new SessionEvent
					(	this,
						pkt.getNthValue("5",i),				// to
						pkt.getNthValue("4",i),				// from
						pkt.getNthValue("14",i),			// message
						pkt.getNthValue("15",i)				// timestamp
					);
					new FireEvent().fire(se,SERVICE_X_OFFLINE);
					i++;  s=pkt.getNthValue("31",i);
				}
			}
			else								// Sent while we are online
			{	SessionEvent se = new SessionEvent
				(	this,
					pkt.getValue("5"),						// to
					pkt.getValue("4"),						// from
					pkt.getValue("14")						// message
				);
				new FireEvent().fire(se,SERVICE_MESSAGE);
			}
		}catch(Exception e) { throw new YMSG9BadFormatException("message",false); }
	}

	// -----------------------------------------------------------------
	// Process an incoming NEWMAIL packet, informing us of how many unread
	// Yahoo mail messages we have.
	// -----------------------------------------------------------------
	protected void receiveNewMail(YMSG9Packet pkt)			// 0x0b
	{	try
		{	SessionNewMailEvent se;
			if(pkt.getValue("43")==null)		// Count only
			{	se = new SessionNewMailEvent
				(	this,
					pkt.getValue("9")						// new mail count
				);
			}
			else								// Mail message
			{	se = new SessionNewMailEvent
				(	this,
					pkt.getValue("43"),						// from
					pkt.getValue("42"),						// message
					pkt.getValue("18")						// subject
				);
			}
			new FireEvent().fire(se,SERVICE_NEWMAIL);
		}catch(Exception e) { throw new YMSG9BadFormatException("new mail",false); }
	}

	// -----------------------------------------------------------------
	// Process an incoming NOTIFY packet.  "Typing" for example.  (Why
	// these things needs to be sent is beyond me!)
	// -----------------------------------------------------------------
	protected void receiveNotify(YMSG9Packet pkt)			// 0x4b
	{	try
		{	if(pkt.status == 0x01) 	// FIX: documentation says this should be STATUS_TYPING (0x16)
			{	SessionNotifyEvent se = new SessionNotifyEvent
				(	this,
					pkt.getValue("5"),						// to
					pkt.getValue("4"),						// from
					pkt.getValue("14"),						// message (game)
					pkt.getValue("49"),						// type (typing/game)
					pkt.getValue("13")						// mode (on/off)
				);
				se.setStatus(pkt.status);
				new FireEvent().fire(se,SERVICE_NOTIFY);
			}
		}catch(Exception e) { throw new YMSG9BadFormatException("notify",false); }
	}
	
	// -----------------------------------------------------------------
	// Process and incoming USERSTAT packet.
	// -----------------------------------------------------------------
	protected void receiveUserStat(YMSG9Packet pkt)			// 0x0a
	{	status = pkt.status;
	}

	// -----------------------------------------------------------------
	// Note: the term 'packet' here refers to a YMSG message, not a TCP packet
	// (although in almost all cases the two will be synonymous).  This is to
	// avoid confusion with a 'YMSG message' - the actual discussion packet. 
	//
	// service - the Yahoo service number
	// status - the Yahoo status number (not sessionStatus above!)
	// body - the payload of the packet
	//
	// Note: it is assumed that the ConnectionHandler has been open()'d
	// -----------------------------------------------------------------
	protected void sendPacket(PacketBodyBuffer body,int service,long status) throws IOException
	{	network.sendPacket(body,service,status,sessionId);
	}

	protected void sendPacket(PacketBodyBuffer body, int service) throws IOException
	{	sendPacket(body,service,STATUS_AVAILABLE);
	}

	// -----------------------------------------------------------------
	// Dump a report out to stdout
	// -----------------------------------------------------------------
	private void report(String s,YMSG9Packet p)
	{	System.err.println(s+"\n"+p.toString()+"\n");
	}
	
	// -----------------------------------------------------------------
	// Start threads
	// -----------------------------------------------------------------
	private void startThreads()
	{	ipThread = new InputThread();
		pingThread = new PingThread();
	}
	
	// -----------------------------------------------------------------
	// The chances are our input thread will be blocked, and so will not
	// check the quit flag.  If I force the socket closed, this will 
	// apparently unblock the IO (well... you'd expect it to!) and cause
	// the thread to die gracefully without a ThreadDeath.
	// -----------------------------------------------------------------
	private void killThreads()
	{	ipThread.quit=true;  try { network.close(); }catch(IOException e) {}
		pingThread.quit=true;  pingThread.interrupt();
		//ipt.stop();
	}
	
	// -----------------------------------------------------------------
	// Are we logged into Yahoo?
	// -----------------------------------------------------------------
	private void checkStatus() throws IllegalStateException
	{	if(sessionStatus!=MESSAGING)
			throw new IllegalStateException("Not logged in");		
	}

	// -----------------------------------------------------------------
	// Preform a clean up of all data fields to 'reset' instance
	// -----------------------------------------------------------------
	private void cleanUp()
	{	username=null;  password=null;  effectiveID=null;
		cookieY=null;  cookieT=null; cookieC=null;
		imvironment=null;
		customStatusMessage=null;  customStatusBusy=false;
		groups=null;  users=null;  identities=null;
		for(Enumeration e=typingNotifiers.keys();e.hasMoreElements();)
			removeTypingNotification((String)e.nextElement());
		loginOver=false;  loginException=null;
	}

	// -----------------------------------------------------------------
	// A key 16 was received, send an error message event
	// -----------------------------------------------------------------
	private void errorMessage(String m,int sv)
	{	new FireEvent().fire(new SessionErrorEvent(this,m,sv),SERVICE_X_ERROR);
	}
	
	// -----------------------------------------------------------------
	// LOGON packets can contain multiple friend status sections,
	// ISAWAY and ISBACK packets contain only one.  Update the YahooUser
	// details and fire event.
	// -----------------------------------------------------------------
	private void updateFriendsStatus(YMSG9Packet pkt)
	{	// -----Online friends count, however count may be missing if == 1
		// -----(Note: only LOGON packets have multiple friends)
		String s = pkt.getValue("8");			
		if(s==null && pkt.getValue("7")!=null)  s="1";
		// -----Process online friends data
		if(s!=null)
		{	int cnt = Integer.parseInt(s);
			SessionFriendEvent se = new SessionFriendEvent(this,cnt);
			// -----Process each friend
			for(int i=0;i<cnt;i++)
			{	// -----Update user (do not create new user, as client may
				// -----still have reference to old
				YahooUser yu = (YahooUser)users.get(pkt.getNthValue("7",i));
				// -----When we add a friend, we get an status update before
				// -----getting a confirmation FRIENDADD packet (crazy!)
				if(yu==null)
				{	String n = pkt.getNthValue("7",i);
					users.put(n,new YahooUser(n));
				}
				// ----- 7=friend 10=status 17=chat 13=pager
				yu.update
				(	pkt.getNthValue("7",i) , pkt.getNthValue("10",i) ,
					pkt.getNthValue("17",i) , pkt.getNthValue("13",i)
				);
				// -----Custom message?
				if(pkt.getNthValue("19",i)!=null && pkt.getNthValue("47",i)!=null)
				{	yu.setCustom(pkt.getNthValue("19",i),pkt.getNthValue("47",i));
				}
				// -----Add to event object
				se.setYahooUser(i,yu);
			}
			// -----Fire event
			new FireEvent().fire(se,SERVICE_ISAWAY);
		}
	}

	// -----------------------------------------------------------------
	// Inserts the given user into the desired group, if not already 
	// present.  Creates the group if not present.
	// -----------------------------------------------------------------
	private void insertFriend(YahooUser yu,String gr)
	{	int idx;
		// -----Find index for group
		for(idx=0;idx<groups.length;idx++)
			if(groups[idx].getName().equalsIgnoreCase(gr))  break;
		// -----Group not found?  Create!
		if(idx>=groups.length)
		{	YahooGroup[] arr = new YahooGroup[groups.length+1];
			int j=0,k=0;
			while(j<groups.length && groups[j].getName().compareTo(gr)<0)
			{	arr[j]=groups[j];  j++;
			}
			idx=j;  arr[idx] = new YahooGroup(gr);
			while(j<groups.length)
			{	arr[j+1]=groups[j];  j++;
			}
			groups=arr;
		}
		// -----Add user if needs be
		if(groups[idx].getIndexOfFriend(yu.getId())<0)
			groups[idx].addElement(yu);
	}
	
	// -----------------------------------------------------------------
	// Deletes a friend from the desired group, if present.  Removes the
	// group too if now empty.
	// -----------------------------------------------------------------
	private void deleteFriend(YahooUser yu,String gr)
	{	int idx,j;
		// -----Find index for group
		for(idx=0;idx<groups.length;idx++)
			if(groups[idx].getName().equalsIgnoreCase(gr))  break;
		if(idx>=groups.length)  return;
		// -----Find index of friend and remove
		j=groups[idx].getIndexOfFriend(yu.getId());
		if(j<0)  return;
		groups[idx].removeElementAt(j);
		// -----If the groups is empty, remove it too
		if(groups[idx].size()==0)
		{	YahooGroup[] arr = new YahooGroup[groups.length-1];
			for(j=0;j<idx;j++)  arr[j]=groups[j];
			for(j=idx;j<arr.length;j++)  arr[j]=groups[j+1];
			groups=arr;
		}
	}
	
	// -----------------------------------------------------------------
	// Create a unique conference name
	// -----------------------------------------------------------------
	private String getConferenceName()
	{	return username+"-"+conferenceCount++;
	}
	
	private YahooConference getConference(String room) throws NoSuchConferenceException
	{	YahooConference yc = (YahooConference)conferences.get(room);
		if(yc==null)  throw new NoSuchConferenceException("Conference "+room+" not found.");
			else  return yc;
	}
	
	private YahooConference getOrCreateConference(String room)
	{	YahooConference yc = (YahooConference)conferences.get(room);
		if(yc==null) { yc = new YahooConference(room,identities);  conferences.put(room,yc); }
		return yc;
	}

		
	// *****************************************************************
	// Thread for handling network input, dispatching incoming packets 
	// to appropriate methods based upon service id.
	// *****************************************************************
	class InputThread extends Thread
	{	public boolean quit=false;				// Exit run in J2 compliant way
		
		// -----Start input thread
		public InputThread() { super(ymsgThreads,"Network Input");  this.start(); }
		
		// -----Accept packets and send them for processing
		public void run()
		{	while(!quit)
			{	try
				{	process(network.receivePacket());
				}catch(Exception e)
				{	try
					{	SessionExceptionEvent se = new SessionExceptionEvent(Session.this,"Source: InputThread",e);
						new FireEvent().fire(se,SERVICE_X_EXCEPTION);
					}catch(Exception e2) { e2.printStackTrace(); }
				}
			}
		}
		
		// -----Switch on packet type to handler code
		void process(YMSG9Packet pkt) throws Exception
		{	// -----A null packet is sent when the input stream closes
			if(pkt == null) { quit=true;  return; }
			// -----Process header
			sessionId = pkt.sessionId;			// Update sess id in outer class
			if(pkt.status==-1)					// Error packet?
			{	errorMessage(pkt.getValue("16")+"",pkt.service);
				if(pkt.body.length<=2)  return;	// Only error message?
			}	
			// -----Process payload
			switch(pkt.service)				// Jump to service-specific code
			{	case SERVICE_ADDIGNORE :	receiveAddIgnore(pkt);  break;
				case SERVICE_AUTH : 		receiveAuth(pkt);  break;
				case SERVICE_AUTHRESP :		receiveAuthResp(pkt);  break;
				case SERVICE_CONFADDINVITE:	receiveConfAddInvite(pkt);  break;
				case SERVICE_CONFINVITE :	receiveConfInvite(pkt);  break;
				case SERVICE_CONFLOGOFF :	receiveConfLogoff(pkt);  break;
				case SERVICE_CONFLOGON :	receiveConfLogon(pkt);  break;
				case SERVICE_CONFMSG :		receiveConfMsg(pkt);  break;
				case SERVICE_CONTACTIGNORE:	receiveContactIgnore(pkt);  break;
				case SERVICE_CONTACTNEW :	receiveContactNew(pkt);  break;
				case SERVICE_FILETRANSFER : receiveFileTransfer(pkt);  break;
				case SERVICE_FRIENDADD :	receiveFriendAdd(pkt);  break;
				case SERVICE_FRIENDREMOVE :	receiveFriendRemove(pkt);  break;
				case SERVICE_IDACT :		receiveIdAct(pkt);  break;
				case SERVICE_ISAWAY :		receiveIsAway(pkt);  break;
				case SERVICE_ISBACK :		receiveIsBack(pkt);  break;
				case SERVICE_LIST : 		receiveList(pkt);  break;
				case SERVICE_LOGOFF :		receiveLogoff(pkt);  break;
				case SERVICE_LOGON :		receiveLogon(pkt);  break;
				case SERVICE_MESSAGE :		receiveMessage(pkt);  break;
				case SERVICE_NEWMAIL :		receiveNewMail(pkt);  break;
				case SERVICE_NOTIFY :		receiveNotify(pkt);  break;
				case SERVICE_USERSTAT :		receiveUserStat(pkt);  break;
				default : System.out.println("UNKNOWN: "+pkt.toString());  break;
			}
		}
	}
	
	// *****************************************************************
	// Thread for sending ping packets when needed
	// Client sends a ping packet to the server every now and again.
	// *****************************************************************
	class PingThread extends Thread
	{	public boolean quit=false;					// Exit run in J2 compliant way
		public int time = 1000*60*20;				// 20 minutes

		public PingThread()
		{	super(ymsgThreads,"Ping");
			this.setPriority(Thread.MIN_PRIORITY);  this.start();
		}

		public void run()
		{	try { Thread.sleep(time); } catch(InterruptedException e) {}
			while(!quit)
			{	try
				{	transmitPing();
					try { Thread.sleep(time); } catch(InterruptedException e) {}
				}catch(Exception e) {}
			}
		}
	}
	
	// *****************************************************************
	// Thread for sending typing start/stop packets
	// There are two key components here: The first is the keyPressed()
	// method which timestamps the last keypress from its source AWT
	// component and sends typing start packets when needed.  The second
	// is a thread which wakes infrequently to check if the last timestamp
	// is older than the timeout, and sends a typing end packet if so.
	// *****************************************************************
	class TypingNotifier extends java.awt.event.KeyAdapter implements Runnable
	{	public boolean quit=false;					// Exit run in J2 compliant way
		private long lastKey;						// Timestamp of last keypress
		private int timeout = 1000*30;				// 30 second timeout
		private boolean typing=false;				// Current typing mode (t=yes) 
		private Thread thread;						// Timeout monitoring thread
		private Component typeSource;				// Source of typing events	
		private int listenerCnt=0;					// Count how often we've been added
		private String target;						// Yahoo id of target
	
		public TypingNotifier(Component com,String u)
		{	typeSource=com;  target=u;
			typeSource.addKeyListener(this);
			thread = new Thread(ymsgThreads,this,"Typing Notification");  
			thread.setPriority(Thread.MIN_PRIORITY);  
			thread.start();
		}
			
		// -----KeyListener method
		public void keyTyped(KeyEvent ev)
		{	// -----Just incase we get an event before the constructor finished
			// -----or (more likely) we are actually connected to the network
			if(!thread.isAlive() || sessionStatus!=MESSAGING)  return; 
			// -----Store time of key press and sent message is needed
			lastKey = System.currentTimeMillis();
			if(!typing)
			{	try { transmitNotify(target,true," ",NOTIFY_TYPING); }catch(IOException e){}
			}
			typing=true;
		}
		
		// -----Thread to detect typing off (timeout)
		public void run()
		{	try
			{	while(!quit)
				{	// -----Wake every second and check if typing ended
					try { Thread.sleep(1000); } catch(InterruptedException e) {}
					// -----Currently typing, and timed out?  (And connected?)
					if( sessionStatus==MESSAGING && typing && 
						System.currentTimeMillis()-lastKey > timeout )
					{	try { transmitNotify(target,false," ",NOTIFY_TYPING); }catch(IOException e){}
						typing=false;
					}
				}
			}
			finally
			{	typeSource.removeKeyListener(this);
			}
		}

		public void interrupt() { thread.interrupt(); }

		public void stopTyping()
		{	if(typing)
			{	try { transmitNotify(target,false," ",NOTIFY_TYPING); }catch(IOException e){}
				typing=false;
			}
		}		
	}

	// *****************************************************************
	// Thread for firing events to listeners.  This is threaded so the
	// network code which instigates these events can return to listening
	// for input, and not get tied up in each listener's event handler.
	// *****************************************************************
	class FireEvent extends Thread
	{	int type;
		SessionEvent ev;

		// -----Convenience methods
		FireEvent() { super(ymsgThreads,"Event Fired"); }
		void fire(SessionEvent ev,int t) { this.ev=ev;  type=t; start(); }
		public void start() { if(listeners.size()>0) super.start(); }

		// -----Thread which calls event handlers
		public void run()
		{	for(int i=0;i<listeners.size();i++)
			{	SessionListener l = (SessionListener)listeners.elementAt(i);
				switch(type)
				{	case SERVICE_LOGOFF :		l.logoffReceived(ev);  break;
					case SERVICE_ISAWAY : 		l.friendsUpdateReceived((SessionFriendEvent)ev); break;
					case SERVICE_MESSAGE : 		l.messageReceived(ev); break;
					case SERVICE_X_OFFLINE : 	l.offlineMessageReceived(ev);  break;
					case SERVICE_NEWMAIL : 		l.newMailReceived((SessionNewMailEvent)ev);  break;
					case SERVICE_CONTACTNEW :	l.contactRequestReceived((SessionEvent)ev);  break;
					case SERVICE_CONFINVITE :	l.conferenceInviteReceived((SessionConferenceEvent)ev); break;
					case SERVICE_CONFLOGON :	l.conferenceLogonReceived((SessionConferenceEvent)ev); break;
					case SERVICE_CONFLOGOFF :	l.conferenceLogoffReceived((SessionConferenceEvent)ev); break;
					case SERVICE_CONFMSG :		l.conferenceMessageReceived((SessionConferenceEvent)ev); break;
					case SERVICE_FILETRANSFER : l.fileTransferReceived((SessionFileTransferEvent)ev);  break;
					case SERVICE_NOTIFY : 		l.notifyReceived((SessionNotifyEvent)ev); break;
					case SERVICE_LIST : 		l.listReceived(ev); break;
					case SERVICE_FRIENDADD :	l.friendAddedReceived((SessionFriendEvent)ev);  break;
					case SERVICE_FRIENDREMOVE :	l.friendRemovedReceived((SessionFriendEvent)ev);  break;
					case SERVICE_CONTACTREJECT:	l.contactRejectionReceived((SessionEvent)ev);  break;
					case SERVICE_X_ERROR :		l.errorPacketReceived((SessionErrorEvent)ev); break;
					case SERVICE_X_EXCEPTION :	l.errorPacketReceived((SessionErrorEvent)ev); break;
					default :					System.out.println("UNKNOWN event: "+type);  break;
				}
			}
		}
	}
	
	// -----------------------------------------------------------------
	// Test code
	// -----------------------------------------------------------------
	public static void dump(Session s)
	{	YahooGroup[] yg = s.getGroups();
		for(int i=0;i<yg.length;i++)
		{	System.out.print(yg[i].getName()+": ");
			for(int j=0;j<yg[i].size();j++)
			{	YahooUser yu = yg[i].getUserAt(j);
				System.out.print(yu.getId()+" ");
			}
			System.out.print("\n");
		}
		
		Hashtable h = s.getUsers();
		for(Enumeration e=h.keys();e.hasMoreElements();)
		{	String k = (String)e.nextElement();
			YahooUser yu = (YahooUser)h.get(k);
			System.out.println(k+" = "+yu.getId());
		}
		
		String[] sa = s.getIdentities();
		for(int i=0;i<sa.length;i++)
			System.out.print(sa[i]+" ");
		System.out.print("\n");
	}
}
