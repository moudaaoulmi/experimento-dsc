package ymsg.network;

public class NoSuchConferenceException extends java.lang.RuntimeException
{	public NoSuchConferenceException(String m) { super(m); }
}
