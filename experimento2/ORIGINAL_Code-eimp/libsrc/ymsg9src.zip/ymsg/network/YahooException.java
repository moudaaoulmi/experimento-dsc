package ymsg.network;

public abstract class YahooException extends java.lang.Exception
{	public YahooException(String m) { super(m); }
}
