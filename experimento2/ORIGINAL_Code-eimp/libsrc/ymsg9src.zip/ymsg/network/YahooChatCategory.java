package ymsg.network;

import java.io.*;
import java.net.URL;
import java.util.*;

public class YahooChatCategory
{	protected String name;			// Name of cataegory/room
	protected long code;			// Code
	private int level;				// Sub category level
	protected Vector categories,privateRooms,publicRooms;
	private ChatSession session;	// Reference to containing session
	
	private final static String TOP_URL = "http://chat.yahoo.com/c/roomlist/catfeed.html";
	private final static String CAT_URL = "http://chat.yahoo.com/c/roomlist/feed.html?.rmcat=";
	
	private final static String PRIVATE_TOK = "PRIVATE_ROOMS";
	private final static String PUBLIC_TOK = "PUBLIC_ROOMS";

	// -----------------------------------------------------------------
	// CONSTRUCTOR
	// -----------------------------------------------------------------
	YahooChatCategory(ChatSession ss,long cd,int lv,String nm)
	{	session=ss;  code=cd;  level=lv;  name=nm;
		categories = new Vector();
		privateRooms=null;  publicRooms=null;
	}
	
	YahooChatCategory(ChatSession ss,StringTokenizer st)
	{	this
		(	ss ,
			Long.parseLong( st.nextToken().trim() ) ,
			Integer.parseInt( st.nextToken().trim() ) ,
			st.nextToken().trim()
		);
	}

	// -----------------------------------------------------------------
	// Add a new sub category
	// -----------------------------------------------------------------
	void add(YahooChatCategory ycl) { categories.addElement(ycl); }
	
	// -----------------------------------------------------------------
	// Get rooms
	// -----------------------------------------------------------------
	public Vector getPublicRooms() throws IOException
	{	if(publicRooms==null)  loadRooms();
		return publicRooms;
	}
	public Vector getPrivateRooms() throws IOException
	{	if(privateRooms==null)  loadRooms();
		return privateRooms;
	}
	
	public void refresh() throws IOException { loadRooms(); }
	
	// -----------------------------------------------------------------
	// Other accessors
	// -----------------------------------------------------------------
	public int size() { return categories.size(); }
	public YahooChatCategory getCategoryAt(int i)
	{	return (YahooChatCategory)categories.elementAt(i); 
	}
	public String getName() { return name; }
	public long getCode() { return code; }

	// -----------------------------------------------------------------
	// The first time a category is inspected, we need to fetch the
	// data from Yahoo to populate it.
	// -----------------------------------------------------------------
	private void loadRooms() throws IOException
	{	int mode=0;
		privateRooms = new Vector();
		publicRooms = new Vector();
		
		// -----Open a HTTP connection to a given category
		HTTPConnection conn = new HTTPConnection("GET",new URL(CAT_URL+code));
		conn.println("");
		
		// -----Header doesn't terminate with blank line
		String in = conn.readLine();
		while
		(	in!=null && 
			in.trim().length()>0 &&
			!(in.startsWith(PUBLIC_TOK) || in.startsWith(PRIVATE_TOK)) 
		)
		{	in = conn.readLine();
		}
		if(in.trim().length()==0)  in = conn.readLine();
			
		// -----Read each line
		String ln = conn.readLine();
		while(in!=null)
		{	if(in.trim().equals(PUBLIC_TOK))  mode=1;
			else if(in.trim().equals(PRIVATE_TOK))  mode=2;
			else
			{	StringTokenizer st = new StringTokenizer(in,"\t");
				YahooChatRoom ycr = new YahooChatRoom
				(	Long.parseLong(st.nextToken().trim()) ,
					st.nextToken().trim() ,
					Integer.parseInt(st.nextToken().trim()) ,
					st.nextToken().trim() ,
					(mode==1)
				);
				// -----Store this so the session can find it later
				session.chatByName.put(ycr.getName(),ycr);
				// -----Assign either private or public list
				switch(mode)
				{	case 1 :	publicRooms.addElement(ycr);
								break;
					case 2 :	privateRooms.addElement(ycr);
								break;
					default :	System.err.println("Room outside of public/private: "+ycr.toString());
								break;
				}
			}
			in = conn.readLine();
		}
		conn.close();
	}
	
	// -----------------------------------------------------------------
	// This method fetches the top level categories
	// -----------------------------------------------------------------
	static YahooChatCategory getCategories(ChatSession ss) throws IOException
	{	Vector v = new Vector();
		Stack st = new Stack();

		YahooChatCategory top = new YahooChatCategory(ss,0,0,"<root>");
		st.push(top);
		
		// -----Open a HTTP connection to the top level
		HTTPConnection conn = new HTTPConnection("GET",new URL(TOP_URL));
		conn.println("");
		conn.flush();
		
		// -----Header doesn't terminate with blank line
		String in = conn.readLine();
		while( in!=null && in.trim().length()>0 && !Character.isDigit(in.charAt(0)) )
		{	in = conn.readLine();
		}
		if(in.trim().length()==0)  in = conn.readLine();
			
		// -----Read each line into a vector
		while(in!=null)
		{	YahooChatCategory n = new YahooChatCategory(ss,new StringTokenizer(in,"\t"));
			YahooChatCategory o = (YahooChatCategory)st.peek();
			
			if(n.level > o.level)		// New gt old
			{	o.add(n);  st.push(n);
			}
			else if(n.level == o.level)	// Siblings 
			{	st.pop();  
				o = (YahooChatCategory)st.peek();  o.add(n);  
				st.push(n);
			}
			else if(n.level < o.level)	// New lt old
			{	while(n.level <= o.level) 
				{	st.pop();  o=(YahooChatCategory)st.peek();
				}
				o.add(n);  st.push(n);
			}
			
			in = conn.readLine();			
		}
		conn.close();
		return top;
	}	
	
	public String toString() { return "name="+name+" code="+code; } 
	//public String toString() { return name+":"+level; } 
	
	private void printGraph(String tb)
	{	if(categories.size()>0)
		{	System.out.println(tb+"<"+name+">");
			for(int i=0;i<categories.size();i++)
				((YahooChatCategory)categories.elementAt(i)).printGraph(tb+"  ");
			System.out.println(tb+"</"+name+">");
		}
		else
		{	System.out.println(tb+name);
		}
	}	
	
	public static void main(String[] st)
	{	try
		{	YahooChatCategory ycc = getCategories(new ChatSession());
			ycc.printGraph("");
			Vector v = ycc.getCategoryAt(0).getPublicRooms();
			for(int i=0;i<v.size();i++)
			{	System.out.println
				(	((YahooChatRoom)v.elementAt(i)).toString()
				);
			}	
			v = ycc.getCategoryAt(0).getPrivateRooms();
			for(int i=0;i<v.size();i++)
			{	System.out.println
				(	((YahooChatRoom)v.elementAt(i)).toString()
				);
			}	
		}catch(Exception e) { e.printStackTrace(); }
	}
}
