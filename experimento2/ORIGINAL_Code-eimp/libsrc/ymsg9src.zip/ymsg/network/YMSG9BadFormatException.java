package ymsg.network;

public class YMSG9BadFormatException extends java.lang.RuntimeException
{	public YMSG9BadFormatException(String m,boolean b) { super("Bad parse of "+m+" packet"); }
	public YMSG9BadFormatException(String m) { super(m); }
}
