package ymsg.network;

import java.util.Vector;

// *********************************************************************
// Because conference packets can be received in inconvenient orders, this
// class carries a lot of code to compensate.  Conference packets can
// actually arrive both before and (probably) after the formal lifetime
// of the conference (from invite received/accepted to logoff).
// 
// Packets with arrive before an invite are buffered.  When an invite
// arrives the packets are fetched and the buffer null'd (which is
// then used as a flag to determine whether an invite has arrived
// or not).  But using this method, the API user will *ALWAYS* get an
// invite before any other packets.
//
// The closed flag marks a closed conference.  Packets arriving after
// this time should be ignored.
// 
// The users list should not contain any of this user's identities.
// This is why they are screened out by the addUser/addUsers methods.
// *********************************************************************
class YahooConference
{	private Vector users;					// Users in this conference
	private String room;					// Room name
	private boolean closed;					// Conference has been exited?
	private Vector packetBuffer;			// Buffer packets before invite
	private String[] identities;			// User's identities
	
	// -----------------------------------------------------------------
	// CONSTRUCTOR
	// -----------------------------------------------------------------
	YahooConference(String r,String[] i)
	{	users = new Vector();  identities=i;
		room=r;  closed=false;  packetBuffer = new Vector();
	}
	
	// -----------------------------------------------------------------
	// The closed flag is set when this conference is exited.  All
	// further packets from this conference should be ignored.
	// -----------------------------------------------------------------
	void closeConference() { closed=true; }
	boolean isClosed() { return closed; }

	// -----------------------------------------------------------------
	// The packetBuffer object is created when the conference is created
	// and set to null when the conference invite actually arrives.
	// -----------------------------------------------------------------
	// -----Have we been invited yet?
	boolean isInvited() { return (packetBuffer==null); }
	// -----We're received an invite, change status and return buffer
	Vector inviteReceived()
	{	Vector v=packetBuffer;  packetBuffer=null;
		return v;
	}
	// -----Add a packet to the buffer
	void addPacket(YMSG9Packet ev)
	{	if(packetBuffer==null)  throw new IllegalStateException("Cannot buffer packets, invite already received");
		packetBuffer.addElement(ev);
	}

	// -----------------------------------------------------------------
	// Add to and get user list
	// -----------------------------------------------------------------
	Vector getUsers() { return users; }
	synchronized void addUsers(String[] u)
	{	for(int i=0;i<u.length;i++)  addUser(u[i]);
	}
	synchronized void addUser(String u)
	{	if(!exists(u) && !id(u))  users.addElement(u);
	}	
	synchronized void removeUser(String u)
	{	for(int i=0;i<users.size();i++)
		{	if( ((String)users.elementAt(i)).equals(u) )
			{	users.removeElementAt(i);  return;
			}
		}
	}
		
	// -----------------------------------------------------------------
	// Does a user exist in Vector (uses .equals())
	// -----------------------------------------------------------------
	private boolean exists(String s)
	{	for(int i=0;i<users.size();i++)
			if( ((String)users.elementAt(i)).equals(s) )  return true;
		return false;
	}
	
	// -----------------------------------------------------------------
	// Is this one of the user's identities?
	// -----------------------------------------------------------------
	private boolean id(String s)
	{	for(int i=0;i<identities.length;i++)
			if(identities[i].equals(s))  return true;
		return false;
	}
}
