package ymsg.network;

import java.util.*;
import java.io.IOException;

// WORK IN PROGRESS

public class ChatSession implements StatusConstants, ServiceConstants
{	public final static byte[] MAGIC = { 'Y','M','S','G' };
	public final static byte[] VERSION = { 0x09,0x00,0x00,0x00 };
	public final static String SERVER = "scs.yahoo.com";
	public final static int PORT = 5050;
	// -----Misc Yahoo data
	private String server;					// Server to connect to
	private int port;						// Port to connect to
	private String username;				// Yahoo user id
	private String effectiveID;				// Effective Yahoo user id (not implemented)
	private String password;				// Yahoo user password
	// -----Login
	private boolean chatLoginOver=false; 	// Marks start/end of chatroom login
	// -----Chatrooms
	Hashtable chatByName;					// Chatrooms hashed by name


	// -----------------------------------------------------------------
	// Chat rooms
	// -----------------------------------------------------------------
	public YahooChatCategory getCategories()
	{	try { return YahooChatCategory.getCategories(this); }catch(IOException e) {}
		return null;
	}

	public ChatSession()
	{	chatByName = new Hashtable();		// Keep track of known chatrooms
	}

	/*	
	public synchronized void chatLogin(long l)
	{	transmitChatIntro();
		while(!chatLoginOver)
			try { Thread.sleep(10); } catch(InterruptedException e) {}
		// FIX: ... finish this
	}

	
	protected void transmitChatIntro() throws IOException
	{	PacketBodyBuffer body = new PacketBodyBuffer();
		body.addElement("109",username);
		body.addElement("1",effectiveID);  // FIX: is this right?
		body.addElement("6","abcde");  // FIX: what is this?
		sendPacket(body,SERVICE_CHATINTRO);					// 0x96
	}

	protected void transmitChatLogoff(String room) throws IOException
	{	PacketBodyBuffer body = new PacketBodyBuffer();
		body.addElement("104",room);
		body.addElement("109",username);
		sendPacket(body,SERVICE_CHATLOGOFF);				// 0xa0
	}
	
	protected void transmitChatLogon(String room,long code) throws IOException
	{	PacketBodyBuffer body = new PacketBodyBuffer();
		body.addElement("1",effectiveID);  // FIX: is this right?
		body.addElement("104",room);
		body.addElement("129",""+code);
		body.addElement("62","2");  // FIX: what is this?
		sendPacket(body,SERVICE_CHATLOGIN);					// 0x98
	}

	protected void transmitChatMsg(String room,String msg) throws IOException
	{	PacketBodyBuffer body = new PacketBodyBuffer();
		body.addElement("1",effectiveID);  // FIX: is this right?
		body.addElement("104",room);
		body.addElement("117",msg);
		body.addElement("124","1");  // FIX: what is this?
		sendPacket(body,SERVICE_CHATMSG);					// 0xa8
	}
	
	protected void receiveChatIntro(YMSG9Packet pkt)		// 0x96
	{	chatIntroOver=true;
	}

	protected void receiveChatLogon(YMSG9Packet pkt)		// 0x98
	{	try
		{	String room = pkt.getValue("104");
			String desc = pkt.getValue("103");
			YahooChatRoom ycr = (YahooChatRoom)chatByName.get(room);
			// -----Set up users in room
			int cnt = 0;
			while(pkt.getNthValue("109",cnt)!=null)
			{	// FIX: should use an existing user if possible, not create new
				YahooUser yu = new YahooUser
				(	pkt.getNthValue("109") ,				// id
					pkt.getNthValue("110") ,				// status (?) FIX
					"1",									// on chat?
					"0"										// on pager?
				);
				ycr.addUser(yu);
				cnt++;
			}
			// FIX: need some way to remember that we are logged into this room
		}catch(Exception e) { throw new YMSG9BadFormatException("chat login",false);
	}
	*/
}
