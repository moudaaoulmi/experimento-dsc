package ymsg.network.event;


public class SessionNewMailEvent extends SessionEvent
{	protected int mail;
	protected String subject;

	// -----------------------------------------------------------------
	// CONSTRUCTORS
	// -----------------------------------------------------------------
	public SessionNewMailEvent(Object o,String ml)
	{	super(o);
		mail = Integer.parseInt(ml);
	}
	
	public SessionNewMailEvent(Object o,String fr,String msg,String sb)
	{	super(o,null,fr,msg);
		mail=0;  subject=sb;
	}

	// -----------------------------------------------------------------
	// Accessors
	// -----------------------------------------------------------------
	public int getMailCount() { return mail; }
	public String getSubject() { return subject; }
	public boolean isWholeMail() { return (mail==0); }

	public String toString()
	{	return super.toString()+" mail:"+mail+" subject:"+subject;
	}
}
