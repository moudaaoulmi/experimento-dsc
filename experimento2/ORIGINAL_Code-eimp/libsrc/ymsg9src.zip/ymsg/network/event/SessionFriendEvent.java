package ymsg.network.event;

import ymsg.network.YahooUser;

public class SessionFriendEvent extends SessionEvent
{	protected YahooUser[] list;
	protected YahooUser friend;
	protected String group;

	// -----------------------------------------------------------------
	// CONSTRUCTORS
	// -----------------------------------------------------------------
	public SessionFriendEvent(Object o,int sz)  // Friends list update
	{	super(o);
		list = new YahooUser[sz];  friend=null;  group=null;
	}

	public SessionFriendEvent(Object o,YahooUser yu,String gp)  // Friend added
	{	super(o);
		list=null;  friend=yu;  group=gp;
	}
		
	// -----------------------------------------------------------------
	// Accessors
	// -----------------------------------------------------------------
	// -----Friends update
	public void setYahooUser(int i,YahooUser yu) { list[i]=yu; }
	public YahooUser[] getFriends() { return list; }
	// -----Friend added
	public YahooUser getFriend() { return friend; }
	public String getGroup() { return group; }

	public String toString()
	{	if(list!=null)
			return super.toString()+" list(size):"+list.length;
		else
			return super.toString()+" friend:"+friend.getId()+" group:"+group;
	}
}
