package ymsg.network.event;

public class SessionErrorEvent extends SessionEvent
{	protected int service;

	// -----------------------------------------------------------------
	// CONSTRUCTORS
	// -----------------------------------------------------------------
	public SessionErrorEvent(Object o,String m,int sv)
	{	super(o);  message=m;  service=sv;
	}
	
	public int getService() { return service; }

	public String toString()
	{	return "Error: message=\""+message+"\" service=0x"+Integer.toHexString(service);
	}
}
