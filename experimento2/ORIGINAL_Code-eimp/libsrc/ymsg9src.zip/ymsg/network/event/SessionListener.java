package ymsg.network.event;

public interface SessionListener
{	// Someone has sent us a file
	//  to - the target (us!)
	//  from - the user who sent the file
	//  location - the URL of the file data on Yahoo (download this)
	//  datestamp - the date when the URL stops being valid (?)
	//  message - a text message to accompany the file
	public void fileTransferReceived(SessionFileTransferEvent ev);

	// Yahoo has logged us off the system
	public void logoffReceived(SessionEvent ev);

	// A list (friends and groups) update has been received
	public void listReceived(SessionEvent ev);

	// Someone has sent us a message
	//  to - the target (us!)
	//  from - the user who sent the message
	//  message - the message text
	public void messageReceived(SessionEvent ev);

	// Yahoo tells us about a message sent while we were away
	//  to - the target (us!)
	//  from - the user who sent the message
	//  message - the message text
	//  datestamp - the date the message was sent (?)
	public void offlineMessageReceived(SessionEvent ev);
	
	// Someone has sent us a message
	//  message - the message text
	public void errorPacketReceived(SessionErrorEvent ev);

	// Someone has sent us a message
	//  message - the message text
	public void inputExceptionThrown(SessionExceptionEvent ev);
	
	// Yahoo tells us we have unread Yahoo mail
	//  mail - number of unread mails
	public void newMailReceived(SessionNewMailEvent ev);

	// Yahoo server wants to notify us of something
	//  service - the type of request
	//  to - the target (us!)
	//  from - the user who sent the message
	//  mode - 0=off/1=on (for typing)
	public void notifyReceived(SessionNotifyEvent ev);

	// Someone wants to add us to their friends list
	//  to - the target (us!)
	//  from - the user who wants to add us
	//  message - the request message text
	public void contactRequestReceived(SessionEvent ev);

	// Someone has rejected our attempts to add them to our friends list
	//  from - the user who rejected us
	//  message - rejection message text
	public void contactRejectionReceived(SessionEvent ev);
		
	// Someone is inviting us to join a conference.  Use Session.
	// acceptConferenceInvite() to accept or Session.declineSessionInvite() 
	// to decline.
	//  to - the target (us!)
	//  from - the host of the conference (yahoo id)
	//  topic - the topic (or welcome message) of the conference
	//  room - the conference name
	//  users[] - yahoo id's of other users in the conference
	public void conferenceInviteReceived(SessionConferenceEvent ev);
	
	// Someone has joined a conference we are part of.
	//  to - the target (us!)
	//  from - the user joinint (yahoo id)
	//  room - the conference name
	public void conferenceLogonReceived(SessionConferenceEvent ev);

	// Someone is leaving a conference we are part of
	//  to - the target (us!)
	//  from - the user leaving
	//  room - the conference name
	public void conferenceLogoffReceived(SessionConferenceEvent ev);

	// Someone has sent round a message to the conference members
	//  to - the target (us!)
	//  from - the user who sent the message
	//  message - the message text
	//  room - the conference name
	public void conferenceMessageReceived(SessionConferenceEvent ev);
	
	// Friend's details have been updated
	//  friends - vector of updated YahooUser's
	public void friendsUpdateReceived(SessionFriendEvent ev);

	// Successfully added a friend
	//  friend - YahooUser of friend
	//  group - name of group added to
	public void friendAddedReceived(SessionFriendEvent ev);

	// Successfully removed a friend
	//  friend - YahooUser of friend
	//  group - name of group removed from
	public void friendRemovedReceived(SessionFriendEvent ev);
}
