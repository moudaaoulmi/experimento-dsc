package ymsg.network.event;

public class SessionExceptionEvent extends SessionEvent
{	protected Exception exception;

	// -----------------------------------------------------------------
	// CONSTRUCTORS
	// -----------------------------------------------------------------
	public SessionExceptionEvent(Object o,String m,Exception e)
	{	super(o);  message=m;  exception=e;
	}
	
	public Exception getException() { return exception; }

	public String toString()
	{	return "Exception: message=\""+message+"\" type="+exception.toString();
	}

}
