package ymsg.network.event;

import java.util.Date;


public class SessionEvent extends java.util.EventObject
{	protected String to=null,from=null,message=null;
	protected Date timestamp;
	protected long status=0;

	// -----------------------------------------------------------------
	// CONSTRUCTORS
	// -----------------------------------------------------------------
	public SessionEvent(Object o)
	{	super(o);
	}
	
	public SessionEvent(Object o,String t,String f)
	{	this(o);  to=t;  from=f; 
	}

	public SessionEvent(Object o,String t,String f,String m)	// Online message
	{	this(o,t,f);  message=m;
	}

	public SessionEvent(Object o,String t,String f,String m,String dt) // Offline message
	{	this(o,t,f,m);
		try { timestamp = new Date(Long.parseLong(dt)*1000); }
			catch(NumberFormatException e) { timestamp = null; }
	}

	
	// -----------------------------------------------------------------
	// Accessors
	// -----------------------------------------------------------------
	public String getTo() { return to; }
	public String getFrom() { return from; }
	public String getMessage() { return message; }
	public Date getTimestamp() { return timestamp; }

	public long getStatus() { return status; }
	public void setStatus(long s) { status=s; }

	public String toString()
	{	return "to:"+to+" from:"+from+" message:"+message+
			" timestamp:"+timestamp;
	}

	// -----------------------------------------------------------------
	// Convert a rich format Yahoo message to HTML.  Yahoo uses two 
	// methods of marking up its messages: bold, italic, underline and 
	// colour are all achieved thanks to escape sequences, whereas fonts
	// use HTML style markup.
	//
	// Escape sequences begin with the character sequence 0x1b,0x5b (0x1b
	// '[') and end 0x6d ('m').  Between these is a one or two character
	// code.  "1/x1"=bold on/off, "2/x2"=italic on/off, "4/x4"=underline
	// on/off, "30"=black ... "38"=red ... etc.  If the data inside the
	// escape bookends begins with a '#' then it is followed by a 6 digit 
	// hexidecimal colour, of the form RRGGBB.
	//
	// The HTML font takes the form <font face="Courier" size="12"> , but
	// note that there is no corresponding </font> tag.
	// -----------------------------------------------------------------
	public String getMessageAsHTML()
	{	String in=message,out="";
		int boldCnt=0,italicCnt=0,underlineCnt=0,fontCnt=0;

		final String[] COLOURS =
		{	"black",	"blue",		"cyan",		"pink",	"green",
			"grey",		"purple",	"orange",	"red",	"brown"
		};
		final char ESC = 0x1b;
		
		while(in.length()>0)
		{	// -----FIX: checking for "<font " should be case insensitive
			if(in.startsWith("<font "))					// Handle font markup
			{	// -----FIX: checking for ">" should ignore string literals
				out=out+in.substring(0,in.indexOf(">")+1);
				in=in.substring(in.indexOf(">")+1);
				fontCnt++;
			}
			else if(in.charAt(0) == ESC)				// Handle escape code
			{	String s=in.substring(2,in.indexOf("m"));
				if(s.charAt(0)=='x')
				{	switch(s.charAt(1))
					{	case '1' : out=out+"</b>";  boldCnt--;  break;
						case '2' : out=out+"</i>";  italicCnt--;  break;
						case '4' : out=out+"</u>";  underlineCnt--;  break;					
					}
				}
				else if(s.charAt(0)=='#')
				{	out=out+"<font color=\""+s+"\">";
					fontCnt++;
				}
				else
				{	switch(s.charAt(0))
					{	case '1' : out=out+"<b>";  boldCnt++;  break;
						case '2' : out=out+"<i>";  italicCnt++;  break;
						case '4' : out=out+"<u>";  underlineCnt++;  break;
						case '3' :
							out=out+"<font color=\"" + COLOURS[s.charAt(1)-'0'] + "\">";
							fontCnt++;  break;
					}				
				}
				in=in.substring(in.indexOf("m")+1);
			}
			else										// Regular chars
			{	int i=0;
				while(i<in.length() && in.charAt(i)!='<' && in.charAt(i)!=ESC)  i++;
				if(i>0)
				{	out=out+in.substring(0,i);
					in=in.substring(i);
				}
			}
		}
		// -----Close off all the unclosed elements
		for(int i=0;i<boldCnt;i++)  out=out+"</b>";
		for(int i=0;i<italicCnt;i++)  out=out+"</i>";
		for(int i=0;i<underlineCnt;i++)  out=out+"</u>";
		for(int i=0;i<fontCnt;i++)  out=out+"</font>";
		// -----Return completed HTML
		return out;
	}
}
