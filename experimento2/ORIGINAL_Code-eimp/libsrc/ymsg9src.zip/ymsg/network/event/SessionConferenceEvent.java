package ymsg.network.event;

public class SessionConferenceEvent extends SessionEvent
{	private String room;
	private String[] users;

	public SessionConferenceEvent(Object o,String t,String f,String m,String r)
	{	super(o,t,f,m);  room=r;
	}
	public SessionConferenceEvent(Object o,String t,String f,String m,String r,String[] u)
	{	this(o,t,f,m,r);  users=u;
	}
	
	public String getRoom() { return room; }
	public String[] getUsers() { return users; }
	public String getTopic() { return getMessage(); }

	public String toString()
	{	return super.toString()+" room:"+room+" users(size):"+users.length;
	}
}
