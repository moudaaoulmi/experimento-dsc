package ymsg.network;

import java.util.Hashtable;

// *********************************************************************
// This class is nothing more than a convenient data structure to hold
// the information extracted from a single YMSG packet (message).  The
// body array holds the list of strings, in sequence, as they appeared
// in the body section of the packet.
//
// This class is returned by YMSG9InputStreamReader.readPacket();
// See YMSG9InputStream.java for more details on the protocol.
//
// Note: the term 'packet' here is strictly speaking incorrect, as a
// YMSG message could in theory take up more than one TCP packet - but
// it helps to distinguish these lower-level network messages from
// the higher-level dialogue 'message's in the protocol.
// *********************************************************************
class YMSG9Packet
{	String magic;
	int version,length,service;
	long status,sessionId;
	String[] body;
	
	public String toString()
	{	String s=	"Magic:"+magic+" Version:"+version+" Length:"+length+
					" Service:"+service+" Status:"+status+" SessionId:0x"+
					Long.toHexString(sessionId)+"\n "; 
		for(int i=0;i<body.length;i++)  s=s+" ["+body[i]+"]";
		return s;
	}
	
	private int getNthLocation(String k,int n)
	{	for(int i=0;i<body.length;i+=2)
		{	if(body[i].equals(k))  n--;
			if(n<0)  return i;
		}
		return -1;
	}
	
	public String getNthValue(String k,int n)
	{	int l = getNthLocation(k,n);		
		if(l<0)  return null;  else  return body[l+1];
	}
	public String getValue(String k) { return getNthValue(k,0); }
	
	public String[] getValues(String k)
	{	int cnt=0,j=0;
		for(int i=0;i<body.length;i+=2)
			if(body[i].equals(k))  cnt++;
		String[] sa = new String[cnt];
		for(int i=0;i<body.length;i+=2)
			if(body[i].equals(k))  sa[j++]=body[i+1];
		return sa;
	}
}
