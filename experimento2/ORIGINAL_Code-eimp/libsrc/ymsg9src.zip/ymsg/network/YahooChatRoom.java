package ymsg.network;

public class YahooChatRoom
{	protected String name;			// Name of room
	protected long code;			// Code
	protected int number;			// FIX: Not sure what this is!
	protected String pvtRoom;		// FIX: Ditto(!?!)
	protected boolean access;		// True=public, false=private
	
	YahooChatRoom(long cd,String nm,int nu,String rm,boolean ac)
	{	name=nm;  code=cd;  number=nu;  pvtRoom=rm;  access=ac;
	}
	
	public String getName() { return name; }
	public long getCode() { return code; }
	public boolean isPublic() { return access; }
	
	public String toString() { return "name="+name+" code="+code+
	" public?="+access; }
}
