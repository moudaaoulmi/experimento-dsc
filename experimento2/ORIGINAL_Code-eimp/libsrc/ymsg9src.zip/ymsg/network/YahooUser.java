package ymsg.network;

public class YahooUser
{	protected String id;
	protected long status;
	protected boolean onChat,onPager,ignored;
	protected String customStatusMessage;
	protected boolean customStatusBusy;

	public YahooUser(String i,long st,boolean ch,boolean pg) { update(i,st,ch,pg); }
	
	public YahooUser(String i,String st,String ch,String pg) { update(i,st,ch,pg); }

	public YahooUser(String i)
	{	this(i,StatusConstants.STATUS_OFFLINE,false,false);
	}
	
	public String getId() { return id; }
	public long getStatus() { return status; }
	public boolean isOnChat() { return onChat; }
	public boolean isOnPager() { return onPager; }
	public boolean isLoggedIn() { return (onChat||onPager); }
	public boolean isIgnored() { return ignored; }
	public String getCustomStatusMessage() { return customStatusMessage; }
	public boolean isCustomBusy() { return customStatusBusy; }
	void setIgnored(boolean i)
	{	ignored=i;
	}
	void setCustom(String m,String a)
	{	customStatusMessage=m;  customStatusBusy=a.charAt(0)=='1';
	}

	public String toString()
	{	return "id="+id+" status=0x"+Long.toHexString(status)+
			" chat?="+onChat+" pager?="+onPager+" ignored?="+ignored+
			" custMesg="+customStatusMessage+" custBusy?="+customStatusBusy;
	}

	void update(String i,String st,String ch,String pg)
	{	update(i , Long.parseLong(st) , (ch.charAt(0)=='1') , pg.charAt(0)=='1');
	}
	void update(String i,long st,boolean ch,boolean pg)
	{	id=i;  status=st;  onChat=ch;  onPager=pg;
		if(status != StatusConstants.STATUS_CUSTOM)
		{	customStatusMessage=null;  customStatusBusy=false;
		}
	}
}
