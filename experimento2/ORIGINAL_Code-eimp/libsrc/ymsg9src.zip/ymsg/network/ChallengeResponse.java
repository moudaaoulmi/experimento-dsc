package ymsg.network;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

class ChallengeResponse
{	final static int[] CHECKSUM_POS = { 7,9,15,1,3,7,9,15 };

	final static int USERNAME=0,PASSWORD=1,CHALLENGE=2;
	final static int[][] STRING_ORDER = 
	{	{ PASSWORD,USERNAME,CHALLENGE } ,	// 0
		{ USERNAME,CHALLENGE,PASSWORD } ,	// 1
		{ CHALLENGE,PASSWORD,USERNAME } ,	// 2
		{ USERNAME,PASSWORD,CHALLENGE } ,	// 3
		{ PASSWORD,CHALLENGE,USERNAME } ,	// 4
		{ PASSWORD,USERNAME,CHALLENGE } ,	// 5
		{ USERNAME,CHALLENGE,PASSWORD } ,	// 6
		{ CHALLENGE,PASSWORD,USERNAME }		// 7
	};

	final static String Y64 = 	"ABCDEFGHIJKLMNOPQRSTUVWXYZ"+
								"abcdefghijklmnopqrstuvwxyz"+
								"0123456789._";	

	// -----------------------------------------------------------------
	// Given a username, password and challenge string, this code returns
	// the two valid response strings needed to login to Yahoo
	// -----------------------------------------------------------------
	public static String[] getStrings(String username,String password,String challenge)
	throws NoSuchAlgorithmException
	{	String[] s = new String[2];
		s[0] = yahoo64(md5(password));
		s[1] = yahoo64(md5(md5Crypt(password,"$1$_2S43d5f")));

		//System.out.println(s[0]+" "+s[1]);
		
		int mode = challenge.charAt(15) % 8;
		
		// -----The mode determines the 'checksum' character
		char c = challenge.charAt
		(	challenge.charAt
			(	CHECKSUM_POS[mode]
			) % 16
		);
		
		// -----Depending upon the mode, the various strings are combined
		// -----differently
		s[0] = yahoo64( md5( c+combine(username,s[0],challenge,mode) ) );
		s[1] = yahoo64( md5( c+combine(username,s[1],challenge,mode) ) );
		
		return s;
	}
	
	// -----------------------------------------------------------------
	// The 'mode' (see getStrings() above) determines the order the
	// various strings and the hashed/encyrpted password are concatenated.
	// For efficiency I stuff all the values into an array and use a
	// table to determine the order they should be glued together.
	// -----------------------------------------------------------------
	private static String combine(String u,String p,String c,int mode)
	{	String s = ""; 
		String[] sa = { u,p,c };
		for(int i=0;i<3;i++)  s=s+sa[STRING_ORDER[mode][i]];
		return s;
	}

	// -----------------------------------------------------------------
	// Yahoo uses its own custom variation on Base64 encoding (although a
	// little birdy tells me this routine actually comes from the Apple Mac?)
	//
	// For those not familiar with Base64 etc, all this does is treat an
	// array of bytes as a bit stream, sectioning the stream up into six 
	// bit slices, which can be represented by the 64 characters in the
	// 'table' Y64 above.  In this fashion raw binary data can be expressed
	// as valid 7 bit printable ASCII - although the size of the data will
	// expand by 25% - three bytes (24 bits) taking up four ASCII characters.
	// Now obviously the bit stream will terminate mid way throught an ASCII 
	// character if the input array size isn't evenly divisible by 3.  To 
	// flag this, either one or two dashes are appended to the output.  A 
	// single dash if we're two over, and two dashes if we're only one over.
	// (No dashes are appended if the input size evenly divides by 3.)
	// -----------------------------------------------------------------
	private static String yahoo64(byte[] buffer)
	{	int limit = buffer.length-(buffer.length%3);
		int pos=0;
		String out="";
		int[] buff = new int[buffer.length];
		
		for(int i=0;i<buffer.length;i++)  buff[i]=(int)buffer[i] & 0xff;
		
		for(int i=0;i<limit;i+=3)
		{	// -----Top 6 bits of first byte
			out=out+Y64.charAt( buff[i]>>2 );
			// -----Bottom 2 bits of first byte append to top 4 bits of second
			out=out+Y64.charAt( ((buff[i]<<4) & 0x30) | (buff[i+1]>>4) );
			// -----Bottom 4 bits of second byte appended to top 2 bits of third
			out=out+Y64.charAt( ((buff[i+1]<<2) & 0x3c) | (buff[i+2]>>6) );
			// -----Bottom six bits of third byte
			out=out+Y64.charAt( buff[i+2] & 0x3f );
		}
		
		// -----Do we still have a remaining 1 or 2 bytes left?
		int i=limit;
		switch(buff.length-i)
		{	case 1 :
				// -----Top 6 bits of first byte
				out=out+Y64.charAt( buff[i]>>2 );
				// -----Bottom 2 bits of first byte
				out=out+Y64.charAt( ((buff[i]<<4) & 0x30) );
				out=out+"--";  break;
			case 2 :
				// -----Top 6 bits of first byte
				out=out+Y64.charAt( buff[i]>>2 );
				// -----Bottom 2 bits of first byte append to top 4 bits of second
				out=out+Y64.charAt( ((buff[i]<<4) & 0x30) | (buff[i+1]>>4) );
				// -----Bottom 4 bits of second byte
				out=out+Y64.charAt( ((buff[i+1]<<2) & 0x3c) );
				out=out+"-";  break;
		}
		
		return out;
	}
	
	// -----------------------------------------------------------------
	// Return the MD5 or a string and byte array
	// -----------------------------------------------------------------
	private static byte[] md5(String s) throws NoSuchAlgorithmException
	{	return md5(s.getBytes());
	}	
	private static byte[] md5(byte[] buff) throws NoSuchAlgorithmException
	{	return MessageDigest.getInstance("MD5").digest(buff);
	}
	// -----------------------------------------------------------------
	// Return the MD5Crypt of a string and salt
	// -----------------------------------------------------------------
	private static byte[] md5Crypt(String k,String s)
	{	return UnixMD5Crypt.crypt(k,s).getBytes();
	}
	
	// -----------------------------------------------------------------
	// Test code (these are all fake u/p's - so don't bother trying them!)
	// -----------------------------------------------------------------
	public static void main(String[] args)
	{	try
		{	String[] s = ChallengeResponse.getStrings("javakid","dikavaj","S3qrCsgTteaSjH6GUbZOqg--");
			System.out.println(s[0]+" "+s[1]);
			
			s = ChallengeResponse.getStrings("spidey","peterparker","AkONHp_jJNV4SPEDWXw2cg--");
			System.out.println(s[0]+" "+s[1]);
			
			s = ChallengeResponse.getStrings("luke_skywalker","darthishisfather","eyM63R_CYgCuzjGw7nJgGg--");
			System.out.println(s[0]+" "+s[1]);
			
			s = ChallengeResponse.getStrings("sminkypinky","youaintseenmeright","G4MsFLd05F_TgD16VtdNBw--");
			System.out.println(s[0]+" "+s[1]);
		}catch(Exception e) { e.printStackTrace(); }
	}
}
