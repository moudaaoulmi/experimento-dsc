package ymsg.test;

import ymsg.network.*;
import ymsg.network.event.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.IOException;

public class TestClient extends Frame implements ActionListener
{	protected TextField inputTF,toTF;
	protected TextArea outputTA;
	protected Button sendB,sendConfB,refreshB,dumpB,loginB,quitB;
	protected Button addFriendB,removeFriendB;
	protected Button addTypeB,removeTypeB;
	protected Button test1B,test2B;
	
	private static final String FT_DIR = "/tmp";  // File transfer destination

	protected Session session;
	private String username,password;

	// -----------------------------------------------------------------
	// CONSTRUCTOR
	// -----------------------------------------------------------------
	public TestClient(String u,String p,String mode)
	{	super("YMSG9 Test Client: "+u);
		
		username=u;  password=p;

		Panel topP = new Panel(new BorderLayout());
		topP.add(new Label("To:"),BorderLayout.WEST);
		toTF = new TextField();  topP.add(toTF,BorderLayout.CENTER);
		
		outputTA = new TextArea(12,40);  outputTA.setEditable(false);
		
		Panel bottomP = new Panel(new BorderLayout());
		bottomP.add(new Label("Message:"),BorderLayout.WEST);
		inputTF = new TextField();  inputTF.addActionListener(this);
		bottomP.add(inputTF,BorderLayout.CENTER);

		Panel sideP = new Panel(new GridLayout(0,2));
		test1B=makeButton("Test1",sideP);		test2B=makeButton("Test2",sideP);
		sendB=makeButton("Mesg",sideP);			sendConfB=makeButton("Mesg Conf",sideP);
		addFriendB=makeButton("Add Fr",sideP);	removeFriendB=makeButton("Rem Fr",sideP);
		addTypeB=makeButton("Add Ty",sideP);	removeTypeB=makeButton("Rem Ty",sideP);
		refreshB=makeButton("Refresh",sideP);	dumpB=makeButton("Dump",sideP);			
		loginB=makeButton("Login",sideP);		quitB=makeButton("Quit",sideP);

		setLayout(new BorderLayout());
		add(topP,BorderLayout.NORTH);
		add(outputTA,BorderLayout.CENTER);
		add(bottomP,BorderLayout.SOUTH);
		add(sideP,BorderLayout.EAST);
		
		// -----Tell the YMSG9 API we'd like debug data dumped
		System.getProperties().put("ymsg.debug","true");
		
		// -----Set the connection handler as per command line
		if(mode.equals("socks"))  
			session = new Session(new SOCKSConnectionHandler("autoproxy",1080));
		else if(mode.equals("http"))
			session = new Session(new HTTPConnectionHandler("proxy",8080));
		else if(mode.equals("direct"))
			session = new Session(new DirectConnectionHandler());
		else
			session = new Session();

		// -----Register a listener
		session.addSessionListener(new SessionHandler());
		//session.addTypingNotificationSource(inputTF,username);
		
		try { attemptLogin();  dump(); } catch(Exception e) { e.printStackTrace(); }
		pack();  show();  
	}
		
	private void attemptLogin() throws Exception
	{	// -----Login to Yahoo
		try
		{	session.login(username,password);
		}
		catch(AccountLockedException e)
		{	System.out.println("Your account is locked");
			if(e.getWebPage()!=null)  System.out.println("Please visit: "+e.getWebPage().toString());
			throw e;
		}
		catch(LoginRefusedException e)
		{	System.out.println("Yahoo refused our connection.  Username/password incorrect?");
			throw e;
		}

		// -----Are we cooking with gas?
		if(session.getSessionStatus()==StatusConstants.MESSAGING)
		{	System.out.println(session.getConnectionHandler().toString());
		}
		else
		{	System.out.println("Sorry, there was a problem connecting");
		}
	}

	private Button makeButton(String title,Panel p)
	{	Button b = new Button(title);  b.addActionListener(this);  p.add(b);
		return b;
	}	

	// -----------------------------------------------------------------
	// AWT button event handler
	// -----------------------------------------------------------------
	public void actionPerformed(ActionEvent ev)
	{	Object src = ev.getSource();
		try
		{	if(src==sendB)
			{	session.sendMessage(toTF.getText(),inputTF.getText());
				inputTF.setText("");
			}
			else if(src==sendConfB)
			{	session.sendConferenceMessage(toTF.getText(),inputTF.getText()); 
				inputTF.setText("");
			}
			else if(src==addFriendB)
			{	session.addFriend(toTF.getText(),inputTF.getText());
			}
			else if(src==removeFriendB)
			{	session.removeFriend(toTF.getText(),inputTF.getText());
			}
			else if(src==addTypeB)
			{	session.addTypingNotification(toTF.getText(),inputTF);
			}
			else if(src==removeTypeB)
			{	session.removeTypingNotification(toTF.getText());
			}
			else if(src==test1B)
			{	//session.sendFileTransfer("_username_","../test.html","Hello...");
			}
			else if(src==test2B)
			{	
			}
			else if(src==refreshB) { session.refreshFriends(); }
			else if(src==dumpB) { dump(); }
			else if(src==loginB) { attemptLogin(); }
			else if(src==quitB) { session.logout(); }
		}catch(Exception e) { e.printStackTrace(); }
	}

	// -----------------------------------------------------------------
	// YMSG9 session handler
	// -----------------------------------------------------------------
	class SessionHandler extends SessionAdapter
	{	public void messageReceived(SessionEvent ev)
		{	outputTA.append(ev.getFrom()+" : "+ev.getMessageAsHTML()+"\n");
		}
		public void errorMessageReceived(SessionErrorEvent ev)
		{	if(ev.getService()!=ServiceConstants.SERVICE_CONTACTIGNORE)
			{	outputTA.append("ERROR : "+ev.getMessage()+"\n");
				System.err.println(ev.toString());
			}
		}
		public void offlineMessageReceived(SessionEvent ev)
		{	outputTA.append("At "+ev.getTimestamp().toString()+"\n");
			outputTA.append(ev.getFrom()+" : "+ev.getMessageAsHTML()+"\n");
		}
		public void fileTransferReceived(SessionFileTransferEvent ev)
		{	messageReceived(ev);
			System.out.println(ev.getLocation().toString());
			try { session.saveFileTransferTo(ev,FT_DIR); } catch(Exception e) { e.printStackTrace(); }
		}
		public void logoffReceived(SessionEvent ev)
		{	TestClient.this.setVisible(false);  TestClient.this.dispose();
		}
		public void listReceived(SessionEvent ev)
		{	dump();
		}
		public void friendsUpdateReceived(SessionFriendEvent ev)
		{	YahooUser[] l = ev.getFriends();
			for(int i=0;i<l.length;i++)
				System.out.println("Updated: "+l[i].toString());
		}
		public void friendAddedReceived(SessionFriendEvent ev)
		{	System.out.println(ev.toString());
		}
 		public void friendRemovedReceived(SessionFriendEvent ev)
		{	System.out.println(ev.toString());
		}
        public void conferenceInviteReceived(SessionConferenceEvent ev)
		{	System.out.println(ev.toString());
			try
			{	session.declineConferenceInvite(ev.getRoom(),"Sorry!");
			}catch(IOException e) {}
		}
        public void conferenceLogonReceived(SessionConferenceEvent ev)
		{	System.out.println(ev.toString());
		}
        public void conferenceLogoffReceived(SessionConferenceEvent ev)
		{	System.out.println(ev.toString());
		}		
        public void conferenceMessageReceived(SessionConferenceEvent ev)
		{	System.out.println(ev.toString());
		}		
	}

	// -----------------------------------------------------------------
	// Debug
	// -----------------------------------------------------------------
	public void dump()
	{	YahooGroup[] yg = session.getGroups();
		for(int i=0;i<yg.length;i++)
		{	System.out.println(yg[i].getName()+":");
			for(int j=0;j<yg[i].size();j++)
			{	YahooUser yu = yg[i].getUserAt(j);
				System.out.println("  "+yu.toString());
			}
		}
		Hashtable h = session.getUsers();
		for(Enumeration e=h.keys();e.hasMoreElements();)
		{	String k = (String)e.nextElement();
			System.out.println(k+" ==> "+((YahooUser)h.get(k)).toString());
		}
	}

	// -----------------------------------------------------------------
	// Bootstrap
	// -----------------------------------------------------------------
	public static void main(String[] args)
	{	if(args.length>=2)
		{	TestClient tc = new TestClient(args[0],args[1],args[2]);
		}
		else
		{	System.out.println("Need: <username> <password> [direct|socks|http]\n"+args.length);
		}
	}
}
